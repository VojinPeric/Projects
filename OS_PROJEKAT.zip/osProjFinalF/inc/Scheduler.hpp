//
// Created by os on 5/12/24.
//

#ifndef PROJECT_BASE_V1_1_SCHEDULER_HPP
#define PROJECT_BASE_V1_1_SCHEDULER_HPP

class _thread;

typedef _thread *thread_t;

class Scheduler {
public:
    static void printScheduler();
    static void put(thread_t thread);
    static thread_t get();
    static void initScheduler();
private:
    static thread_t head;
    static thread_t tail;
};


#endif //PROJECT_BASE_V1_1_SCHEDULER_HPP
