//
// Created by os on 5/12/24.
//

#ifndef PROJECT_BASE_V1_1__THREAD_HPP
#define PROJECT_BASE_V1_1__THREAD_HPP

#include "syscall_cpp.hpp"
#include "../lib/hw.h"
#include "Scheduler.hpp"
#include "riscv.hpp"
#include "MemAllocator.hpp"

class _sem;

typedef _sem *sem_t;

class _thread;

typedef _thread *thread_t;

class _thread {
public:
    enum State {
        NORMAL,
        FINISHED,
        SEMDEAD,
        TIMEOUT,
        BLOCKED,
        WAITBLOCKED
    };

    void* operator new(size_t size) {
        return MemAllocator::takeSpace(size / MEM_BLOCK_SIZE + (size % MEM_BLOCK_SIZE ? 1 : 0));
    }

    void operator delete(void* ptr) {
        MemAllocator::giveSpace(ptr);
    }

    _thread() : routine(nullptr), arg(nullptr), stack(nullptr), timeSlice(DEFAULT_TIME_SLICE), waitingOn(nullptr),
    timeoutTime(0), threadState(State::NORMAL) {}

    _thread(void (*routine)(void*), void* arg, void* stack) : routine(routine), arg(arg), stack(stack),
    timeSlice(DEFAULT_TIME_SLICE), waitingOn(nullptr), timeoutTime(0), threadState(State::NORMAL) {
        context.sp = (uint64)stack + DEFAULT_STACK_SIZE;
        context.ra = (uint64)&_thread::wrapper;
        Scheduler::put(this);
    }

    ~_thread();

    State getState() const { return threadState; }
    void setState(State state) { threadState = state; }
    sem_t getSem() { return waitingOn; }
    void setSem(sem_t sem) { waitingOn = sem; }

    static void yield();
    static void exit();

    static thread_t popThreadStart (thread_t& head, int port);
    static void pushThreadEnd (thread_t& head, thread_t& tail, thread_t thread, int port);
    static void pushThreadStart (thread_t& head, thread_t& tail, thread_t thread, int port);
    static void pushInFront (thread_t curr, thread_t thread, int port);
    static thread_t getNext (thread_t curr, int port);

    static thread_t popThreadStartD (thread_t& head, int port);
    static void pushThreadEndD (thread_t& head, thread_t& tail, thread_t thread, int port);
    static void pushThreadStartD (thread_t& head, thread_t& tail, thread_t thread, int port);
    static void pushInFrontD (thread_t curr, thread_t thread, int port);
    static void deleteElemD (thread_t& head, thread_t& tail, thread_t thread, int port);

    static uint64 findTimeoutTime(uint64 timeout);
    static int compareTime(uint64 time1, uint64 time2);
    static uint64 getGlobalTime() { return globalThreadTime; };

    time_t getTimeoutTime() const { return timeoutTime; };
    void setTimeoutTime(time_t t) { timeoutTime = t; };



    // privilegovane funkcije

    static int create(thread_t *handle,
                       void(*start_routine)(void *),
                       void *arg,
                       void *stack_space);

    static void dispatch();

    static void initThread(thread_t main);

    static thread_t running;
private:

    struct Context {
        uint64 ra;
        uint64 sp;
    };

    static void wrapper();
    static void swapContext(Context* oldT, Context* newT);

    static void incrementGlobalTime();

    static uint64 globalThreadTime;

    static uint64 currTime;

    friend class Riscv;
    friend class Scheduler;

    Context context;
    void (*routine)(void*);
    void* arg;
    void* stack;
    const uint64 timeSlice;
    thread_t nextPointers[2] = {nullptr, nullptr}; // 0 - all cases except timed, 1 - timed list
    thread_t prevPointers[2] = {nullptr, nullptr}; // 0 - all cases except timed, 1 - timed list
    sem_t waitingOn;
    time_t timeoutTime;
    State threadState;

    // threadGroup pointer
};


#endif //PROJECT_BASE_V1_1__THREAD_HPP
