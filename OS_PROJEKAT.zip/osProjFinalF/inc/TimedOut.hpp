//
// Created by os on 5/14/24.
//

#ifndef PROJECT_BASE_V1_1_TIMEDOUT_HPP
#define PROJECT_BASE_V1_1_TIMEDOUT_HPP

#include "../lib/hw.h"
#include "_thread.hpp"

class TimedOut {
public:

    static int timeWait(time_t timeout);

    static void initTimedOut();
    static void putTimeout(time_t timeout);
    static void checkAndFree();

    static void deleteFromList(thread_t th);

private:

    static thread_t head;
    static thread_t tail;

};


#endif //PROJECT_BASE_V1_1_TIMEDOUT_HPP
