//
// Created by os on 5/8/24.
//

#ifndef PROJECT_BASE_V1_1_CONSOLEHELPER_HPP
#define PROJECT_BASE_V1_1_CONSOLEHELPER_HPP

#include "../lib/hw.h"

void print_uint64(uint64 num);
void printStringMy(const char *str);

#endif //PROJECT_BASE_V1_1_CONSOLEHELPER_HPP
