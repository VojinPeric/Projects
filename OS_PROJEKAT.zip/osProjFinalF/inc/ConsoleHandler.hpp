//
// Created by os on 5/18/24.
//

#ifndef PROJECT_BASE_V1_1_CONSOLEHANDLER_HPP
#define PROJECT_BASE_V1_1_CONSOLEHANDLER_HPP
#include "_thread.hpp"
#include "_sem.hpp"


class ConsoleHandler {
public:
    static void initBuffers();
    static void deleteBuffers();

    static bool bufferGetIsEmpty();
    static bool bufferPutIsEmpty();

    static bool bufferGetIsFull();
    static bool bufferPutIsFull();

    static void readChar(char c);

    static char popGet();
    static char popPut();

    static void pushGet(char c);
    static void pushPut(char c);

    static char userGet();
    static void userPut(char c);

    static void printString(const char* str);

    static void printInt(int num);

    static void printUInt64(uint64 num);
private:
    static constexpr int BUFFER_SIZE = 200;

    static char bufferGet[BUFFER_SIZE];
    static char bufferPut[BUFFER_SIZE];

    static int getLength;
    static int getHead;
    static int getTail;

    static int putLength;
    static int putHead;
    static int putTail;

    static sem_t semGet;
    static sem_t semPut;
};


#endif //PROJECT_BASE_V1_1_CONSOLEHANDLER_HPP
