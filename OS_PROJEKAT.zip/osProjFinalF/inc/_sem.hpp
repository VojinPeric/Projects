//
// Created by os on 5/13/24.
//

#ifndef PROJECT_BASE_V1_1__SEM_HPP
#define PROJECT_BASE_V1_1__SEM_HPP

#include "../lib/hw.h"
#include "_thread.hpp"
#include "TimedOut.hpp"

class _sem {
public:
    void* operator new(size_t size) {
        return MemAllocator::takeSpace(size / MEM_BLOCK_SIZE + (size % MEM_BLOCK_SIZE ? 1 : 0));
    }

    void operator delete(void* ptr) {
        MemAllocator::giveSpace(ptr);
    }

    _sem(unsigned init = 0) : value(init), headBlocked(nullptr), tailBlocked(nullptr) {};

    static int create(sem_t* handler, unsigned init);
    static int closeSem(sem_t handler);

    int getValue() const { return value; };

    int signal();
    int wait();
    int timedWait(time_t timeout);
    int tryWait();
    void close();

    void deleteFromList(thread_t th);

private:
    friend class Riscv;

    void pushBlocked();
    int popBlocked();

    void putTimeout(time_t time);

    int value;

    thread_t headBlocked;
    thread_t tailBlocked;

    // semGroup pointer
    // next pointer
};


#endif //PROJECT_BASE_V1_1__SEM_HPP
