//
// Created by os on 5/8/24.
//

#ifndef PROJECT_BASE_V1_1_MEMALLOCATOR_HPP
#define PROJECT_BASE_V1_1_MEMALLOCATOR_HPP
#include "../lib/hw.h"

class MemAllocator {
public:
    static void *takeSpace(size_t blocks);

    static int giveSpace(void *p);

    static void initializeMem(); // inicijalizuje heap kernela

    static void printListAndBefores();

    MemAllocator(const MemAllocator &) = delete;

    MemAllocator(MemAllocator &&) = delete;

private:
    typedef struct Node {
        bool isFree;
        size_t blocks;
        Node *segmentBefore;
        Node *next;
        Node *prev;
    } Node;

    MemAllocator() {}

    static Node *takeAll(Node *);

    static Node *takeFragment(Node *, size_t);

    static void connectAll(Node* header, Node* before, Node* next);
    static void connectBefore(Node* header, Node* before);
    static void connectNext(Node* header, Node* next);
    static void addToList(Node* header);
    static Node* getNextHeader(Node* curr);

    static Node* first;
    static uint64 start;
    static uint64 end;
};

#endif //PROJECT_BASE_V1_1_MEMALLOCATOR_HPP
