//
// Created by os on 5/8/24.
//

#include "../h/syscall_c.hpp"
void *mem_alloc(size_t size) {
    return BINARY::mem_alloc(size / MEM_BLOCK_SIZE + (size % MEM_BLOCK_SIZE ? 1 : 0));
}

int mem_free(void * p) {
    return BINARY::mem_free(p);
}

int thread_create(thread_t *handle, void(*start_routine)(void *), void *arg) {
    void* stack = mem_alloc(DEFAULT_STACK_SIZE);
    if (!stack) return -1;
    int status = BINARY::thread_create(handle, start_routine, arg, stack);
    if(status < 0) {
        mem_free(stack);
        return -2;
    }
    return status;
}

int thread_exit() {
    BINARY::thread_exit();
    return 0;
}

void thread_dispatch() {
    BINARY::thread_dispatch();
}

int sem_open(sem_t *handle, unsigned init) {
    return BINARY::sem_open(handle, init);
}

int sem_close(sem_t handle) {
    return BINARY::sem_close(handle);
}

int sem_wait(sem_t id) {
    return BINARY::sem_wait(id);
}

int sem_signal(sem_t id) {
    return BINARY::sem_signal(id);
}

int sem_timedwait(sem_t id, time_t timeout) {
    return BINARY::sem_timedwait(id, timeout);
}

int sem_trywait(sem_t id) {
    return BINARY::sem_trywait(id);
}

int time_sleep(time_t time) {
    return BINARY::time_sleep(time);
}

char getc() {
    return BINARY::getc();
}

void putc(char c) {
    return BINARY::putc(c);
}
