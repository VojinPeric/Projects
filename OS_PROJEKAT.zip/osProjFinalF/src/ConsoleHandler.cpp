//
// Created by os on 5/18/24.
//

#include "../h/ConsoleHandler.hpp"

char ConsoleHandler::bufferGet[BUFFER_SIZE] = {};
char ConsoleHandler::bufferPut[BUFFER_SIZE] = {};

int ConsoleHandler::getLength = 0;
int ConsoleHandler::getHead = 0;
int ConsoleHandler::getTail = 0;

int ConsoleHandler::putLength = 0;
int ConsoleHandler::putHead = 0;
int ConsoleHandler::putTail = 0;

sem_t ConsoleHandler::semGet = 0;
sem_t ConsoleHandler::semPut = 0;

void ConsoleHandler::initBuffers() {
    getHead = 0;
    getTail = 0;
    getLength = 0;
    putHead = 0;
    putTail = 0;
    putLength = 0;
    sem_open(&semGet, 0);
    sem_open(&semPut, BUFFER_SIZE);
}

void ConsoleHandler::deleteBuffers() {
    sem_close(semGet);
    sem_close(semPut);
}

bool ConsoleHandler::bufferGetIsEmpty() {
    return semGet->getValue() <= 0;
}

bool ConsoleHandler::bufferPutIsEmpty() {
    return semPut->getValue() == BUFFER_SIZE;
}

bool ConsoleHandler::bufferGetIsFull() {
    return semGet->getValue() == BUFFER_SIZE;
}

bool ConsoleHandler::bufferPutIsFull() {
    return semPut->getValue() <= 0;
}

char ConsoleHandler::popGet() {
    semGet->wait();
    char c = bufferGet[getHead];
    getHead = (getHead + 1) % BUFFER_SIZE;
    return c;

}

char ConsoleHandler::popPut() {
    char c = bufferPut[putHead];
    putHead = (putHead + 1) % BUFFER_SIZE;
    semPut->signal();
    return c;
}

void ConsoleHandler::pushGet(char c) {
    bufferGet[getTail] = c;
    getTail = (getTail + 1) % BUFFER_SIZE;
    semGet->signal();
}

void ConsoleHandler::pushPut(char c) {
    semPut->wait();
    bufferPut[putTail] = c;
    putTail = (putTail + 1) % BUFFER_SIZE;
    while (Riscv::canWriteConsole()) {
        if (!bufferPutIsEmpty()) {
            Riscv::writeConsole(popPut());
        }
        else break;
    }
}

char ConsoleHandler::userGet() {
    return popGet();
}

void ConsoleHandler::userPut(char c) {
    pushPut(c);
}

void ConsoleHandler::printUInt64(uint64 num) {
    if (num == 0) {
        userPut('0');
        return;
    }

    char buffer[20];
    int i = 0;

    while (num > 0) {
        buffer[i++] = (num % 10) + '0';
        num /= 10;
    }

    for (int j = i - 1; j >= 0; j--) {
        userPut(buffer[j]);
    }
}

void ConsoleHandler::printInt(int num) {
    if (num == 0) {
        userPut('0');
        return;
    }

    if (num < 0) {
        userPut('-');
        num = -num;
    }

    char buffer[10];
    int i = 0;

    while (num > 0) {
        buffer[i++] = (num % 10) + '0';
        num /= 10;
    }

    for (int j = i - 1; j >= 0; j--) {
        userPut(buffer[j]);
    }
}

void ConsoleHandler::printString(const char* str) {
    while (*str) {
        userPut(*str);
        str++;
    }
}
