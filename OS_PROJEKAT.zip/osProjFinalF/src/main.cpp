#include "../h/MemAllocator.hpp"
#include "../h/riscv.hpp"
#include "../h/_thread.hpp"
#include "../h/TimedOut.hpp"
#include "../h/ConsoleHandler.hpp"
#include "../h/consoleHelper.hpp"

extern void userMain();

void idleBody(void* arg) {
    bool* finishIdle = (bool*)arg;
    while (!(*finishIdle)) thread_dispatch();
    *finishIdle = false;
}

void usetMainWrapper(void*) {
    userMain();
}

int main() {
    Riscv::w_stvec((uint64) &Riscv::supervisorTrap);

    MemAllocator::initializeMem();

    thread_t mainT = new _thread();

    _thread::initThread(mainT);
    Scheduler::initScheduler();

    TimedOut::initTimedOut();

    ConsoleHandler::initBuffers();

    thread_t userMainThread;
    thread_create(&userMainThread, &usetMainWrapper, nullptr);

    Riscv::ms_sstatus(Riscv::SSTATUS_SIE);

    while (userMainThread->getState() != _thread::State::FINISHED) thread_dispatch();

    Riscv::mc_sstatus(Riscv::SSTATUS_SIE);

    delete mainT;

    ConsoleHandler::deleteBuffers();

    Riscv::halt();

    return 0;
}
