//
// Created by os on 5/11/24.
//

#include "../h/syscall_binary.hpp"
#include "../h/consoleHelper.hpp"

void *BINARY::mem_alloc(size_t blocks) {
    return (void*) ecallWrapper(0x01, blocks);
}

int BINARY::mem_free(void * p) { return (int) ecallWrapper(0x02, (uint64)p); }

int BINARY::thread_create(
        thread_t *handle,
        void(*start_routine)(void *),
        void *arg,
        void *stack_space
) { return (int) ecallWrapper(0x11, (uint64)handle, (uint64)start_routine, (uint64)arg, (uint64)stack_space); }

int BINARY::thread_exit() { return (int) ecallWrapper(0x12); }

void BINARY::thread_dispatch() { ecallWrapper(0x13); }

int BINARY::sem_open(sem_t *handle, unsigned init) { return (int) ecallWrapper(0x21, (uint64)handle, init); }

int BINARY::sem_close(sem_t handle) { return (int) ecallWrapper(0x22, (uint64)handle); }

int BINARY::sem_wait(sem_t id) { return (int) ecallWrapper(0x23, (uint64)id); }

int BINARY::sem_signal(sem_t id) { return (int) ecallWrapper(0x24, (uint64)id); }

int BINARY::sem_timedwait(sem_t id, time_t timeout) { return (int) ecallWrapper(0x25, (uint64)id, timeout); }

int BINARY::sem_trywait(sem_t id) { return (int) ecallWrapper(0x26, (uint64)id); }

int BINARY::time_sleep(time_t t) { return (int) ecallWrapper(0x31, t); }

char BINARY::getc() { return (char) ecallWrapper(0x41); }

void BINARY::putc(char c) { ecallWrapper(0x42, c); }
