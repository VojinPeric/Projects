//
// Created by os on 5/8/24.
//

#include "../h/MemAllocator.hpp"
#include "../h/consoleHelper.hpp"

MemAllocator::Node* MemAllocator::first = nullptr;

uint64 MemAllocator::start = 0;

uint64 MemAllocator::end = 0;

int MemAllocator::giveSpace(void *p) {
    Node* header = (Node*)((uint64)p - MEM_BLOCK_SIZE);
    if (header < (void*)start && header > (void*)end) return -2;
    if (header->isFree) return -1;

    Node* before = header->segmentBefore;
    Node* next = (getNextHeader(header) < (void*)end ? getNextHeader(header) : nullptr);

    if (before && before->isFree) {
        if (next && next->isFree) connectAll(header, before, next);
        else connectBefore(header, before);
    }
    else {
        if (next && next->isFree) connectNext(header, next);
        else addToList(header);
    }

    return 0;
}

void *MemAllocator::takeSpace(size_t blocks) {
    MemAllocator::Node* curr;
    for(curr = first; curr; curr = curr->next) {
        if (curr->blocks >= blocks) break;
    }
    if (!curr) return nullptr;

    Node* headerNew;
    if (curr->blocks - 1 <= blocks) headerNew = takeAll(curr);
    else headerNew = takeFragment(curr, blocks);

    return (void*) ((uint64)headerNew + MEM_BLOCK_SIZE);
}

void MemAllocator::initializeMem() {
    start = (uint64)HEAP_START_ADDR + (MEM_BLOCK_SIZE - (uint64)HEAP_START_ADDR % MEM_BLOCK_SIZE);
    end = (uint64)HEAP_END_ADDR - (uint64)HEAP_END_ADDR % MEM_BLOCK_SIZE;
    first = (Node*) start;

    first->isFree = true;
    first->blocks = (size_t)((end - start) / MEM_BLOCK_SIZE - 1);
    first->segmentBefore = nullptr;
    first->next = nullptr;
    first->prev = nullptr;
}

MemAllocator::Node *MemAllocator::takeFragment(MemAllocator::Node * curr, size_t blocks) {
    size_t blockOffs = curr->blocks - blocks - 1;
    Node* newHeader = (Node*)((uint64)curr + (blockOffs + 1) * MEM_BLOCK_SIZE);

    newHeader->isFree = false;
    newHeader->blocks = blocks;
    newHeader->segmentBefore = curr;

    Node* headerNext = getNextHeader(curr);
    if (headerNext < (void*)end) {
        headerNext->segmentBefore = newHeader;
    }

    curr->blocks -= blocks + 1;
    return newHeader;
}

MemAllocator::Node *MemAllocator::takeAll(MemAllocator::Node * curr) {
    if (!curr->prev) first = curr->next;
    else curr->prev->next = curr->next;
    if (curr->next) curr->next->prev = curr->prev;
    curr->isFree = false;
    return curr;
}

void MemAllocator::printListAndBefores() {
    Node* firstInLine = (Node*) start;
    Node* nextInLine = getNextHeader(firstInLine);
    while (nextInLine < (void*)end) {
        if (nextInLine->segmentBefore != firstInLine) {
            print_uint64(0);
            return;
        }

        print_uint64((uint64)firstInLine);


        firstInLine = nextInLine;
        nextInLine = getNextHeader(nextInLine);

        printStringMy("\n");
    }
    print_uint64(1);
    printStringMy("\n");

    for (Node* curr = first; curr; curr = curr->next) {
        print_uint64((uint64)curr);
        printStringMy("\n");
        printStringMy("Free: ");
        printStringMy((curr->isFree ? "true" : "false"));
        printStringMy("\n");
        printStringMy("Blocks: ");
        print_uint64(curr->blocks);
        printStringMy("\n");
        printStringMy("Next: ");
        print_uint64((uint64)curr->next);
        printStringMy("\n");
        printStringMy("Prev: ");
        print_uint64((uint64)curr->prev);
        printStringMy("\n");
        printStringMy("Segment Before: ");
        print_uint64((uint64)curr->segmentBefore);
        printStringMy("\n");
        printStringMy("----------------");
        printStringMy("\n");
    }
}

void MemAllocator::connectAll(MemAllocator::Node *header, MemAllocator::Node *before, MemAllocator::Node *next) {
    before->blocks += header->blocks + next->blocks + 2;
    Node* later = getNextHeader(next);
    if (later < (void*)end) later->segmentBefore = before;
    takeAll(next);
}

void MemAllocator::connectBefore(MemAllocator::Node *header, MemAllocator::Node *before) {
    before->blocks += header->blocks + 1;
    Node* later = getNextHeader(header);
    if (later < (void*)end) later->segmentBefore = before;
}

void MemAllocator::connectNext(MemAllocator::Node *header, MemAllocator::Node *next) {
    header->isFree = true;
    header->blocks += next->blocks + 1;
    Node* later = getNextHeader(next);
    if (later < (void*)end) later->segmentBefore = header;
    header->next = next->next;
    header->prev = next->prev;
    if (next->prev) next->prev->next = header;
    else first = header;
    if (next->next) next->next->prev = header;
}

void MemAllocator::addToList(MemAllocator::Node *header) {
    header->isFree = true;
    header->next = first;
    header->prev = nullptr;
    first = header;
    if (header->next) header->next->prev = header;
}

MemAllocator::Node *MemAllocator::getNextHeader(MemAllocator::Node *curr) {
    return (Node*)((uint64)curr + (curr->blocks + 1)*MEM_BLOCK_SIZE);
}
