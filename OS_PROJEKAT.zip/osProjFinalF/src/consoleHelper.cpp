//
// Created by os on 5/8/24.
//

#include "../h/consoleHelper.hpp"
#include "../h/syscall_c.hpp"

void print_uint64(uint64 num) {
    char buffer[21];
    int index = 0;

    if (num == 0) {
        putc('0');
        return;
    }

    while (num != 0) {
        buffer[index++] = '0' + (num % 10);
        num /= 10;
    }

    for (int i = index - 1; i >= 0; i--) {
        putc(buffer[i]);
    }
}

void printStringMy(char const *string)
{
    while (*string != '\0')
    {
        putc(*string);
        string++;
    }
}
