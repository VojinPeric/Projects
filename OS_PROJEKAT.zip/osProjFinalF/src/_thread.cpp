//
// Created by os on 5/12/24.
//

#include "../h/_thread.hpp"
#include "../h/syscall_c.hpp"
#include "../h/syscall_cpp.hpp"
#include "../h/MemAllocator.hpp"
#include "../h/consoleHelper.hpp"

thread_t _thread::running = nullptr;
uint64 _thread::currTime = 0;
uint64 _thread::globalThreadTime = 0;

void _thread::wrapper() {
    Riscv::toUnprivilegedRegime();
    running->routine(running->arg);
    thread_exit();
}

void _thread::initThread(thread_t main) {
    running = main;
    currTime = 0;
    globalThreadTime = 0x0000000000000000UL;
}

void _thread::yield() {
    thread_dispatch();
}

int _thread::create(thread_t *handle,
            void(*start_routine)(void *),
            void *arg,
            void *stack_space) {
    thread_t newThread = new _thread(start_routine, arg, stack_space);
    if (handle == nullptr) return -1;
    if (newThread == nullptr) return -2;
    if (start_routine == nullptr) return -3;
    *handle = newThread;
    return 0;
}



void _thread::dispatch() {
    currTime = 0;
    thread_t old = running;
    if (old->threadState == NORMAL) Scheduler::put(old);
    running = Scheduler::get();
    if (old->threadState == FINISHED) {
        if (old->stack) MemAllocator::giveSpace(old->stack);
        MemAllocator::giveSpace(old);
    }
    if (running != old) swapContext(&old->context, &running->context);
}

uint64 _thread::findTimeoutTime(uint64 timeout) {
    return globalThreadTime + timeout;
}

int _thread::compareTime(uint64 time1, uint64 time2) {
    if (globalThreadTime & 0x8000000000000000UL) {
        if ((0x8000000000000000UL ^ time2) > (0x8000000000000000UL ^ time1)) return 1;
        else if ((0x8000000000000000UL ^ time2) < (0x8000000000000000UL ^ time1)) return -1;
        return 0;
    }
    if (time2 > time1) return 1;
    else if (time2 < time1) return -1;
    return 0;
}

void _thread::incrementGlobalTime() {
    globalThreadTime++;
}

thread_t _thread::popThreadStart(thread_t &head, int port) {
    if(!head) return nullptr;
    thread_t elem = head;
    head = head->nextPointers[port];
    elem->nextPointers[port] = nullptr;
    return elem;
}

void _thread::pushThreadEnd(thread_t &head, thread_t &tail, thread_t thread, int port) {
    tail = (head ? tail->nextPointers[port] : head) = thread;
    thread->nextPointers[port] = nullptr;
}

void _thread::pushInFront(thread_t curr, thread_t thread, int port) {
    thread->nextPointers[port] = curr->nextPointers[port];
    curr->nextPointers[port] = thread;
}

thread_t _thread::getNext(thread_t curr, int port) {
    return curr->nextPointers[port];
}

void _thread::pushThreadStart(thread_t &head, thread_t &tail, thread_t thread, int port) {
    thread->nextPointers[port] = head;
    head = thread;
    if (!head->nextPointers[port]) tail = head;
}

void _thread::exit() {
    //if (running->arg) MemAllocator::giveSpace(running->arg);
    running->threadState = FINISHED;
    Riscv::dispatchWrapper();
}

_thread::~_thread() {

}

thread_t _thread::popThreadStartD(thread_t &head, int port) {
    if (!head) return nullptr;
    thread_t elem = head;
    head = head->nextPointers[port];
    elem->nextPointers[port] = nullptr;
    if (head) head->prevPointers[port] = nullptr;
    return elem;
}

void _thread::pushThreadEndD(thread_t &head, thread_t &tail, thread_t thread, int port) {
    if (!head) {
        head = tail = thread;
        return;
    }
    thread->prevPointers[port] = tail;
    tail->nextPointers[port] = thread;
    tail = thread;
    thread->nextPointers[port] = nullptr;
}

void _thread::pushThreadStartD(thread_t &head, thread_t &tail, thread_t thread, int port) {
    if(!head) {
        head = tail = thread;
        return;
    }
    thread->nextPointers[port] = head;
    head->prevPointers[port] = thread;
    head = thread;
    thread->prevPointers[port] = nullptr;
}

void _thread::pushInFrontD(thread_t curr, thread_t thread, int port) {
    thread->nextPointers[port] = curr->nextPointers[port];
    thread->prevPointers[port] = curr;
    curr->nextPointers[port] = thread;
    thread->nextPointers[port]->prevPointers[port] = thread;
}

void _thread::deleteElemD(thread_t &head, thread_t &tail, thread_t thread, int port) {
    if (thread == head && thread == tail) {
        head = nullptr;
        tail = nullptr;
    }
    else if (thread == head) {
        head = head->nextPointers[port];
        head->prevPointers[port] = nullptr;
        thread->nextPointers[port] = nullptr;
    }
    else if (thread == tail) {
        tail = tail->prevPointers[port];
        tail->nextPointers[port] = nullptr;
        thread->prevPointers[port] = nullptr;
    }
    else {
        thread->nextPointers[port]->prevPointers[port] = thread->prevPointers[port];
        thread->prevPointers[port]->nextPointers[port] = thread->nextPointers[port];
        thread->nextPointers[port] = nullptr;
        thread->prevPointers[port] = nullptr;
    }
}
