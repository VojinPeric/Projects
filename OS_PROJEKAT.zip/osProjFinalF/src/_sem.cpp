//
// Created by os on 5/13/24.
//

#include "../h/_sem.hpp"
#include "../h/consoleHelper.hpp"

int _sem::signal() {
    if (value++ < 0) if(popBlocked() < 0) return -1;
    return 0;
}

int _sem::wait() {
    if (--value < 0) pushBlocked();
    if (_thread::running->getState() == _thread::State::SEMDEAD) {
        _thread::running->setState(_thread::State::NORMAL);
        return -1;
    }
    return 0;
}

int _sem::timedWait(time_t timeout) {
    if (--value < 0) putTimeout(timeout);
    if (_thread::running->getState() == _thread::State::SEMDEAD) {
        _thread::running->setState(_thread::State::NORMAL);
        return -1;
    }
    if (_thread::running->getState() == _thread::State::TIMEOUT) {
        _thread::running->setState(_thread::State::NORMAL);
        value++;
        return -2;
    }
    return 0;
}

int _sem::tryWait() {
    if (value <= 0) return 1;
    value--;
    return 0;
}

void _sem::pushBlocked() {
    _thread::running->setState(_thread::State::BLOCKED);
    _thread::pushThreadEndD(headBlocked, tailBlocked, _thread::running, 0);
    Riscv::dispatchWrapper();
}

int _sem::popBlocked() {
    thread_t th = _thread::popThreadStartD(headBlocked, 0);
    if (!th) return -1;
    if (th->getState() == _thread::State::WAITBLOCKED) TimedOut::deleteFromList(th);
    th->setState(_thread::State::NORMAL);
    Scheduler::put(th);
    return 0;
}

void _sem::putTimeout(time_t timeout) {
    TimedOut::putTimeout(timeout);
    _thread::pushThreadEndD(headBlocked, tailBlocked, _thread::running, 0);
    _thread::running->setState(_thread::State::WAITBLOCKED);
    _thread::running->setSem(this);
    Riscv::dispatchWrapper();
}

void _sem::close() {
    for (thread_t elem = _thread::popThreadStartD(headBlocked, 0); elem; elem = _thread::popThreadStartD(headBlocked, 0)) {
        if (elem->getState() == _thread::State::WAITBLOCKED) TimedOut::deleteFromList(elem);
        elem->setState(_thread::State::SEMDEAD);
        Scheduler::put(elem);
    }
}

int _sem::create(sem_t* handler, unsigned init) {
    sem_t semHandler = new _sem(init);
    if (!semHandler) return -1;
    *handler = semHandler;
    return 0;
}

int _sem::closeSem(sem_t handler) {
    handler->close();
    delete handler;
    return 0;
}

void _sem::deleteFromList(thread_t th) {
    _thread::deleteElemD(headBlocked, tailBlocked, th, 0);
}