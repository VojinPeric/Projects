//
// Created by os on 5/8/24.
//

#include "../h/syscall_cpp.hpp"

// Allocator

void *operator new(size_t s) {
    return mem_alloc(s);
}
void *operator new[](size_t s) {
    return mem_alloc(s);
}

void operator delete(void * p) {
    mem_free(p);
}
void operator delete[](void * p) {
    mem_free(p);
}

// Thread

Thread::Thread(void (*body)(void *), void *arg) : myHandle(nullptr), body(body), arg(arg) {}

Thread::~Thread() { }

int Thread::start() {
    if (myHandle) return -1;
    return thread_create(&myHandle, body, arg);
}

void Thread::dispatch() {
    thread_dispatch();
}

int Thread::sleep(time_t t) {
    return time_sleep(t);
}

Thread::Thread() : myHandle(nullptr), body(&runWrapper), arg(this) {}

void Thread::runWrapper(void * th) {
    ((Thread*)th)->run();
}

// Semaphore

Semaphore::Semaphore(unsigned init) {
    sem_open(&myHandle, init);
}

Semaphore::~Semaphore() {
    sem_close(myHandle);
}

int Semaphore::wait() {
    return sem_wait(myHandle);
}

int Semaphore::signal() {
    return sem_signal(myHandle);
}

int Semaphore::timedWait(time_t t) {
    return sem_timedwait(myHandle, t);
}

int Semaphore::tryWait() {
    return sem_trywait(myHandle);
}

// PeriodicThread

void PeriodicThread::terminate() {
    period = 0;
}

void PeriodicThread::periodicActivationWrapper(void * arg) {
    PeriodicThread* th = (PeriodicThread*) arg;
    while (th->period) {
        th->periodicActivation();
        Thread::sleep(th->period);
    }
}

PeriodicThread::PeriodicThread(time_t period) : Thread(&periodicActivationWrapper, this), period(period) {}

// Console

char Console::getc() {
    return ::getc();
}

void Console::putc(char c) {
    ::putc(c);
}
