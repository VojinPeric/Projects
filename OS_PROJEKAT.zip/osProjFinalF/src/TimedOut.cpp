//
// Created by os on 5/14/24.
//

#include "../h/TimedOut.hpp"
#include "../h/_sem.hpp"
#include "../h/consoleHelper.hpp"
#include "../h/ConsoleHandler.hpp"

thread_t TimedOut::head = nullptr;
thread_t TimedOut::tail = nullptr;

int TimedOut::timeWait(time_t timeout) {
    putTimeout(timeout);
    Riscv::dispatchWrapper();
    _thread::running->setState(_thread::State::NORMAL);
    return 0;
}

void TimedOut::putTimeout(time_t timeout) {
    _thread::running->setState(_thread::State::BLOCKED);
    uint64 time = _thread::findTimeoutTime(timeout);
    _thread::running->setTimeoutTime(time);
    if (!head || _thread::compareTime(head->getTimeoutTime(), time) <= 0) {
        _thread::pushThreadStartD(head, tail, _thread::running, 1);
    }
    else {
        thread_t elem, prev;
        for (elem = _thread::getNext(head, 1), prev = head; elem; elem = _thread::getNext(elem, 1)) {
            if (_thread::compareTime(elem->getTimeoutTime(), time) <= 0) {
                _thread::pushInFrontD(prev, _thread::running, 1);
                break;
            }
            prev = elem;
        }
        if (!elem) {
            _thread::pushThreadEndD(head, tail, _thread::running, 1);
        }
    }
}

void TimedOut::checkAndFree() {
    for (; head; _thread::popThreadStart(head, 1)) {
        if (_thread::compareTime(_thread::getGlobalTime(), head->getTimeoutTime()) <= 0) {
            if (head->getState() == _thread::State::WAITBLOCKED)  head->getSem()->deleteFromList(head);
            head->setState(_thread::State::TIMEOUT);
            Scheduler::put(head);
        }
        else break;
    }
}

void TimedOut::initTimedOut() {
    head = nullptr;
    tail = nullptr;
}

void TimedOut::deleteFromList(thread_t th) {
    _thread::deleteElemD(head, tail, th, 1);
}
