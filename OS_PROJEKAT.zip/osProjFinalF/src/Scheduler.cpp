//
// Created by os on 5/12/24.
//

#include "../h/Scheduler.hpp"
#include "../h/_thread.hpp"
#include "../h/consoleHelper.hpp"

thread_t Scheduler::head = nullptr;
thread_t Scheduler::tail = nullptr;

void Scheduler::initScheduler() {
    head = nullptr;
    tail = nullptr;
}

void Scheduler::put(thread_t thread) {
    _thread::pushThreadEnd(head, tail, thread, 0);
}

thread_t Scheduler::get() {
    return _thread::popThreadStart(head, 0);
}

void Scheduler::printScheduler() {
    printStringMy("Scheduler--------------------------\n");
    for (thread_t elem = head; elem; elem = _thread::getNext(elem, 0)) {
        print_uint64((uint64)elem);
        printStringMy(", funkcija: ");
        print_uint64((uint64)elem->routine);
        printStringMy("\n");
    }
    printStringMy(".Scheduler--------------------------\n");
}