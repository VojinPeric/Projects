//
// Created by os on 5/10/24.
//
#include "../h/riscv.hpp"
#include "../h/consoleHelper.hpp"
#include "../h/MemAllocator.hpp"
#include "../h/_thread.hpp"
#include "../h/_sem.hpp"
#include "../h/ConsoleHandler.hpp"

void Riscv::popSppSpie()
{
    __asm__ volatile ("csrw sepc, ra");
    __asm__ volatile ("sret");
}

void Riscv::handleSupervisorTrap() {
    volatile uint64 operation, firstArg, secondArg, thirdArg, forthArg;
    operation = getRegA0();
    firstArg = getRegA1();
    secondArg = getRegA2();
    thirdArg = getRegA3();
    forthArg = getRegA4();
    volatile uint64 status = r_scause();
    switch(status) {
        case 0x0:
            break;
        case 0x8000000000000001:
            //printString("timer\n");
            mc_sip(BitMaskSip::SIP_SSIP);
            _thread::currTime++;
            _thread::incrementGlobalTime();
            TimedOut::checkAndFree();
            if (_thread::currTime >= _thread::running->timeSlice) {
                dispatchWrapper();
            }
            setRegA1(1);
            break;
        case 0x8000000000000009:
            //printString("console\n");
            if (plic_claim() == 0x0a) {
                while (canReadConsole()) {
                    if (!ConsoleHandler::bufferGetIsFull()) {
                        ConsoleHandler::pushGet(readConsole());
                    }
                    else break;
                }
                while (canWriteConsole()) {
                    if (!ConsoleHandler::bufferPutIsEmpty()) {
                        writeConsole(ConsoleHandler::popPut());
                    }
                    else break;
                }
                plic_complete(0x0a);
            }
            setRegA1(1);
            break;
        case 0x0000000000000002:
            ConsoleHandler::printString("Neispravna instrukcija!");
            halt();
        case 0x0000000000000005:
            ConsoleHandler::printString("Nedozvoljena adresa čitanja!");
            halt();
        case 0x0000000000000007:
            ConsoleHandler::printString("Nedozvoljena adresa upisa!");
            halt();
    }
    if( status == 0x0000000000000008 || status == 0x0000000000000009) {
        //printString("korisnicki ecall ili supervizor ecall\n");
        w_sepc(r_sepc() + 4);
        mc_sip(SIP_SSIP);
        switch(operation) {
            case 0x01:
                //printString("mem_alloc argumenti:\n");
                //print_uint64(firstArg);
                //printString("\n");
                firstArg = (uint64)MemAllocator::takeSpace(firstArg);
                setRegA1(0);
                setRegA0(firstArg);
                break;
            case 0x02:
                //printString("mem_free argumenti:\n");
                //print_uint64(firstArg);
                //printString("\n");
                firstArg = (uint64)MemAllocator::giveSpace((void*)firstArg);
                setRegA1(0);
                setRegA0(firstArg);
                break;
            case 0x11:
                /*
                printString("thread_create argumenti:\n");
                print_uint64(firstArg);
                printString("\n");
                print_uint64(secondArg);
                printString("\n");
                print_uint64(thirdArg);
                printString("\n");
                print_uint64(forthArg);
                printString("\n");*/
                _thread::create((thread_t *)firstArg, (void(*)(void*))secondArg, (void*)thirdArg, (void*)forthArg);
                setRegA1(0);
                break;
            case 0x12:
                //printString("thread_exit argumenti:\n");
                _thread::exit();
                setRegA1(1);
                setRegA0(0);
                break;
            case 0x13:
                dispatchWrapper();
                setRegA1(1);
                break;
            case 0x21:
                /*
                printString("sem_open argumenti:\n");
                print_uint64(firstArg);
                printString("\n");
                print_uint64(secondArg);
                printString("\n");*/
                firstArg = _sem::create((sem_t*) firstArg, (unsigned) secondArg);
                setRegA1(0);
                setRegA0(firstArg);
                break;
            case 0x22:/*
                printString("sem_close argumenti:\n");
                print_uint64(firstArg);
                printString("\n");*/
                firstArg = _sem::closeSem((sem_t) firstArg);
                setRegA1(0);
                setRegA0(firstArg);
                break;
            case 0x23:/*
                printString("sem_wait argumenti:\n");
                print_uint64(firstArg);
                printString("\n");*/
                firstArg = ((sem_t)(firstArg))->wait();
                setRegA1(0);
                setRegA0(firstArg);
                break;
            case 0x24:/*
                printString("sem_signal argumenti:\n");
                print_uint64(firstArg);
                printString("\n");*/
                firstArg = ((sem_t)(firstArg))->signal();
                setRegA1(0);
                setRegA0(firstArg);
                break;
            case 0x25:
                /*printString("sem_timedwait argumenti:\n");
                print_uint64(firstArg);
                printString("\n");
                print_uint64(secondArg);
                printString("\n");*/
                firstArg = ((sem_t)(firstArg))->timedWait((time_t)secondArg);
                setRegA1(0);
                setRegA0(firstArg);
                break;
            case 0x26:
               /* printString("sem_trywait argumenti:\n");
                print_uint64(firstArg);
                printString("\n");*/
                firstArg = ((sem_t)(firstArg))->tryWait();
                setRegA1(0);
                setRegA0(firstArg);
                break;
            case 0x31:
                TimedOut::timeWait((time_t) firstArg);
                setRegA1(0);
                setRegA0(firstArg);
                break;
            case 0x41:
                //printString("getc argumenti:\n");
                firstArg = ConsoleHandler::userGet();
                setRegA1(0);
                setRegA0(firstArg);
                break;
            case 0x42:
                /*printString("putc argumenti:\n");
                print_uint64(firstArg);
                printString("\n");*/
                ConsoleHandler::userPut((char)firstArg);
                setRegA1(0);
                break;
        }
    }
}

void Riscv::toUnprivilegedRegime() {
    mc_sstatus(BitMaskSstatus::SSTATUS_SPP);
    __asm__ volatile ("csrw sepc, ra");
    __asm__ volatile ("sret");
}

void Riscv::dispatchWrapper() {
    volatile uint64 sepc = r_sepc();
    volatile uint64 sstatus = r_sstatus();
    _thread::dispatch();
    w_sstatus(sstatus);
    w_sepc(sepc);
}
