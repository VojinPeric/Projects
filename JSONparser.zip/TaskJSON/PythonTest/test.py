import json

# File name of the JSON file
file_name = '../TestFiles/userTest.json'

# File name of the result file
result_name = '../TestFiles/jsonResult.txt'

with open(file_name, 'r') as file:
    data = json.load(file)

expr = [
data["root"][0]["level1_a"][0]["level2_a"][1]["level3_b"],
data["root"][0]["level1_a"][0]["level2_a"][1]["level3_b"] + data["root"][1]["level1_b"][0]["level2_b"][1]["level3_e"],
data["root"][0]["level1_a"][0]["level2_a"][1]["level3_b"] * data["root"][1]["level1_b"][0]["level2_b"][1]["level3_e"],
data["root"][1]["level1_b"][0]["level2_b"][1]["level3_e"] - data["root"][0]["level1_a"][0]["level2_a"][1]["level3_b"],
data["root"][1]["level1_b"][0]["level2_b"][1]["level3_e"] / data["root"][0]["level1_a"][0]["level2_a"][1]["level3_b"],
(data["root"][0]["level1_a"][0]["level2_a"][1]["level3_b"] + data["root"][1]["level1_b"][0]["level2_b"][1]["level3_e"]) * len(data["root"][0]["level1_a"][0]["level2_a"][0]["level3_a"]),
data["root"][0]["level1_a"][0]["level2_a"][2]["level3_c"][0]["level4_a"],
max(data["root"][0]["level1_a"][0]["level2_a"][1]["level3_b"], data["root"][0]["level1_a"][0]["level2_a"][2]["level3_c"][1]["level4_b"]) - min(data["root"][0]["level1_a"][0]["level2_a"][2]["level3_c"][0]["level4_a"][0]),
data["root"]
]

i = 0
isTrue = True
sol = ""

with open(result_name, 'r') as file:
    for line in file:
        if line.strip() == "---":
            if isinstance(expr[i], (int, float)):
                expr[i] = int(expr[i])
                if (str(expr[i])).strip() != sol.strip():
                    isTrue = False
                    break
            print(str(i) + " : " + str(expr[i]).strip())
            sol = ""
            i += 1
            continue
        sol += line

print(isTrue)