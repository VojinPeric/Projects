//
// Created by Vojin on 10/18/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_HASHBUILDER_H
#define LLDB_DEBUGGER_FOR_WINDOWS_HASHBUILDER_H
#include <stack>
#include <string>
using namespace std;
class HashTree;
class RealNode;

class HashBuilder {
public:
    HashBuilder(const char* file) : file(file) {};
    HashTree* build();

private:
    enum State {
        MAKE_OBJECT, // {
        WAIT_FOR_NAME, // "
        NAME_OBJECT, // "
        WAIT_OBJECT, // " { [ ] 0-9
        STRING, // "
        NUMBER, // ] , }
        AFTER_OBJECT // ] , }
    };

    RealNode* current = nullptr;
    State state = MAKE_OBJECT;
    const char* file;
    stack<RealNode*> path;
    string holder;
    int totalCounter = 0;
    int lineCounter = 0;

    static void (*functionArray[7])(HashBuilder*, char);

    static void make_object_function(HashBuilder*, char);
    static void wait_for_name_function(HashBuilder*, char);
    static void name_object_function(HashBuilder*, char);
    static void wait_object_function(HashBuilder*, char);
    static void string_function(HashBuilder*, char);
    static void number_function(HashBuilder*, char);
    static void after_object_function(HashBuilder*, char);

    void initNewObject();
    void initNewListObject();
    void revert();
};


#endif //LLDB_DEBUGGER_FOR_WINDOWS_HASHBUILDER_H
