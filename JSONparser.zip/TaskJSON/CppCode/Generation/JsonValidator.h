//
// Created by Vojin on 10/20/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_JSONVALIDATOR_H
#define LLDB_DEBUGGER_FOR_WINDOWS_JSONVALIDATOR_H
#include <bitset>
#include <stack>
#include "../OperationResult/OperationResultError.h"
using namespace std;

class JsonValidator {
public:

    JsonValidator (const char* file) : file(file),
    possibleChars("00001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111111111111111111111111111")
    {}

    void validate();

private:
    enum State {
        START_COND,
        START_NAME,
        FIRST_LETTER,
        NEXT_LETTER,
        SEPP,
        VALUE,
        NUMBER,
        END_COND,
        ITERATOR_COND,
        STRING,
        VALUE_WITH_CLOSED
    };

    static void start_cond_function(JsonValidator*, char);
    static void start_name_function(JsonValidator*, char);
    static void first_letter_function(JsonValidator*, char);
    static void next_letter_function(JsonValidator*, char);
    static void sepp_function(JsonValidator*, char);
    static void value_function(JsonValidator*, char);
    static void number_function(JsonValidator*, char);
    static void end_cond_function(JsonValidator*, char);
    static void iterator_function(JsonValidator*, char);
    //static void value_with_closed_function(JsonValidator*, char);
    static void string_function(JsonValidator*, char);

    static void (*functionArray[10])(JsonValidator*, char);
    static bitset<128> bitsetArr[10];

    void changeState(State s);

    stack<bool> openedBrackets;
    bool lastExecutedComa = false;
    State currentState = START_COND;
    bitset<128> possibleChars;
    const char* file;
};


#endif //LLDB_DEBUGGER_FOR_WINDOWS_JSONVALIDATOR_H
