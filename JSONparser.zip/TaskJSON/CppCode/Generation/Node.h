//
// Created by Vojin on 10/18/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_NODE_H
#define LLDB_DEBUGGER_FOR_WINDOWS_NODE_H
#include <vector>
#include <string>
using namespace std;
class RealNode;

class Node {
public:
    enum Type {
        OBJECT,
        STRING,
        NUMBER,
        OBJECT_LIST,
        NONE
    };

    virtual int len() = 0;
    virtual bool canDelete() = 0;
    virtual string getValue(const char* file) = 0;
    virtual Type getType() const = 0;
    virtual RealNode* getNext(int i = 0) const = 0;
    virtual string* getName() = 0;
    virtual void setName(string& s) = 0;

    virtual ~Node() = default;
};

#endif //LLDB_DEBUGGER_FOR_WINDOWS_NODE_H
