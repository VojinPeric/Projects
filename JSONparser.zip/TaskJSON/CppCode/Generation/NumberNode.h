//
// Created by Vojin on 10/29/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_NUMBERNODE_H
#define LLDB_DEBUGGER_FOR_WINDOWS_NUMBERNODE_H
#include "Node.h"


class NumberNode : public Node {
public:
    NumberNode(string num) : Node(), num(num) {}
    int len() override {return 0;}
    virtual bool canDelete() override {return true;}
    virtual string getValue(const char* file) override {return num;}
    string* getName() override {return nullptr;};
    void setName(string& s) override {};
    virtual Type getType() const override {return NUMBER;}
    virtual RealNode* getNext(int i = 0) const override {return nullptr;}

    virtual ~NumberNode() = default;
private:
    string num;
};


#endif //LLDB_DEBUGGER_FOR_WINDOWS_NUMBERNODE_H
