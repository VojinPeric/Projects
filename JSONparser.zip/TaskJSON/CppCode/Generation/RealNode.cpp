//
// Created by Vojin on 10/29/2024.
//

#include "RealNode.h"
#include <fstream>
#include "../OperationResult/ErrorCantOpenFile.h"

string RealNode::getValue(const char* file) {
    ifstream fio;
    fio.open(file);
    if (!fio) throw ErrorCantOpenFile(string("") + file);
    fio.seekg(start, ios::beg);
    string holder;
    for (int i = start; i <= end; i++) {holder += fio.get();}
    return holder;
}
