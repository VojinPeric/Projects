//
// Created by Vojin on 10/29/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_REALNODE_H
#define LLDB_DEBUGGER_FOR_WINDOWS_REALNODE_H
#include "Node.h"
class HashBuilder;

class RealNode : public Node {
    friend class HashBuilder;
public:
    virtual int len() override {return children.size();}
    virtual bool canDelete() override {return false;}
    virtual string getValue(const char* file) override;
    virtual Type getType() const {return type;};
    virtual RealNode* getNext(int i = 0) const {
        if (i >= children.size()) return nullptr;
        return children.at(i);
    }
    virtual string* getName() = 0;
    virtual void setName(string& s) = 0;

    virtual ~RealNode() = default;

protected:
    Type type = NONE;
    int start;
    int end;
    vector<RealNode*> children;
};


#endif //LLDB_DEBUGGER_FOR_WINDOWS_REALNODE_H
