//
// Created by Vojin on 10/18/2024.
//

#include "JsonGenerator.h"

void JsonGenerator::run(JsonGenerator * th) {
    *(th->monitor) = nullptr;
    th->validate();
    if (*(th->monitor)) return;
    th->build();
}

void JsonGenerator::build() {
    HashBuilder* builder = new HashBuilder(file);
    HashTree* product = nullptr;
    try {
        product = builder->build();
    }
    catch (OperationResultError& e) {
        *(monitor) = new string(e.getResult());
    }
    delete builder;
    *location = product;
}

void JsonGenerator::validate() {
    JsonValidator* validator = new JsonValidator(file);
    try {
        validator->validate();
    }
    catch (OperationResultError& e) {
        *(monitor) = new string(e.getResult());
    }
    delete validator;
}

void JsonGenerator::join() {
    th->join();
}
