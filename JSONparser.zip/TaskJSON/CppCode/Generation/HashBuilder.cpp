//
// Created by Vojin on 10/18/2024.
//

#include "HashBuilder.h"
#include "../OperationResult/ErrorWrongSintax.h"
#include "../OperationResult/ErrorCantBuild.h"
#include "../OperationResult/ErrorCantOpenFile.h"
#include "Object.h"
#include "ObjectList.h"
#include "../Hasher/HashTree.h"
#include <fstream>

void (*HashBuilder::functionArray[7])(HashBuilder *, char) = {
        make_object_function,
        wait_for_name_function,
        name_object_function,
        wait_object_function,
        string_function,
        number_function,
        after_object_function
};

HashTree *HashBuilder::build() {
    HashTree* newTree = new HashTree();
    current = newTree->getRoot();
    ifstream fio;
    string line;
    fio.open(file);
    if (!fio) {
        delete newTree;
        throw ErrorCantOpenFile(string("cant open file named: ") + file);
    }
    while (fio) {
        char c = fio.get();
        try {
            functionArray[state](this, c);
        }
        catch (exception& e) {
            delete newTree;
            throw ErrorCantBuild("Exception while building the map");
        }
        totalCounter++;
        if (c == '\n') {
            lineCounter++;
            totalCounter++;
        }
    }
    fio.close();
    return newTree;
}

void HashBuilder::make_object_function(HashBuilder * th, char c) {
    if (c == '{') {
        th->initNewObject();
    }
}

void HashBuilder::wait_for_name_function(HashBuilder * th, char c) {
    if (c == '\"') {
        th->state = NAME_OBJECT;
    }
}

void HashBuilder::name_object_function(HashBuilder * th, char c) {
    if (c == '\"') {
        th->current->setName(th->holder);
        th->holder.clear();
        th->state = WAIT_OBJECT;
    }
    else th->holder += c;
}

void HashBuilder::wait_object_function(HashBuilder * th, char c) {
    if (c == '\"') {
        if (th->current->type == Node::OBJECT_LIST) {
            th->initNewListObject();
        }
        th->current->start = th->totalCounter;
        th->current->end = th->lineCounter;
        th->current->type = Node::STRING;
        th->state = STRING;
    }
    else if (c == '{') {
        if (th->current->type == Node::OBJECT_LIST) {
            th->initNewListObject();
        }
        th->initNewObject();
    }
    else if (c == '[')  {
        if (th->current->type == Node::OBJECT_LIST) {
            th->initNewListObject();
        }
        th->current->type = Node::OBJECT_LIST;
        th->current->start = th->totalCounter;
        th->current->end = th->lineCounter;
    }
    else if (c == ']') {
        th->current->end = th->totalCounter - (th->lineCounter - th->current->end);
        th->state = AFTER_OBJECT;
    }
    else if (c >= '0' && c <= '9') {
        if (th->current->type == Node::OBJECT_LIST) {
            th->initNewListObject();
        }
        th->current->start = th->totalCounter;
        th->current->end = th->lineCounter;
        th->current->type = Node::NUMBER;
        th->state = NUMBER;
    }
}

void HashBuilder::string_function(HashBuilder * th, char c) {
    if (c == '\"') {
        th->current->end = th->totalCounter - (th->lineCounter - th->current->end);
        th->state = AFTER_OBJECT;
    }
}

void HashBuilder::number_function(HashBuilder * th, char c) {
    if (c < '0' || c > '9') {
        th->current->end = th->totalCounter - 1;
        if (c == ']' || c == '}' || c == ',') {
            after_object_function(th, c);
        }
        else {
            th->state = AFTER_OBJECT;
        }
    }
}

void HashBuilder::after_object_function(HashBuilder * th, char c) {
    if (c == ']') {
        th->state = AFTER_OBJECT;
        th->revert();
        th->current->end = th->totalCounter - (th->lineCounter - th->current->end);
    }
    else if (c == '}') {
        th->state = AFTER_OBJECT;
        th->revert();
        th->current->end = th->totalCounter - (th->lineCounter - th->current->end);
    }
    else if (c == ',') {
        th->state = WAIT_OBJECT;
        th->revert();
    }
}

void HashBuilder::initNewObject() {
    current->start = totalCounter;
    current->end = lineCounter;
    current->type = Node::OBJECT;
    current->children.push_back(new Object());
    path.push(current);
    current = current->children.at(current->children.size() - 1);
    state = WAIT_FOR_NAME;
}

void HashBuilder::initNewListObject() {
    path.push(current);
    current->children.push_back(new ObjectList());
    current = current->children.at(current->children.size() - 1);
}

void HashBuilder::revert() {
    current = path.top();
    path.pop();
}
