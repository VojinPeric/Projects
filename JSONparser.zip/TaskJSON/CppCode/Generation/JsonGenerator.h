//
// Created by Vojin on 10/18/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_JSONGENERATOR_H
#define LLDB_DEBUGGER_FOR_WINDOWS_JSONGENERATOR_H
#include <thread>
#include <bitset>
#include <stack>
#include "HashBuilder.h"
#include "JsonValidator.h"
#include "../OperationResult/OperationResultError.h"
using namespace std;

class JsonGenerator {
public:
    JsonGenerator(string** m, const char* file, HashTree** location) : monitor(m), file(file), location(location) {
        th = new thread(run, this);
    }
    ~JsonGenerator() {delete th;}

    void join();

private:
    static void run(JsonGenerator*);

    void build();
    void validate();

    thread* th;
    string** monitor;
    const char* file;
    HashTree** location;
};


#endif //LLDB_DEBUGGER_FOR_WINDOWS_JSONGENERATOR_H
