//
// Created by Vojin on 10/18/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_OBJECTLIST_H
#define LLDB_DEBUGGER_FOR_WINDOWS_OBJECTLIST_H
#include "RealNode.h"

class ObjectList : public RealNode {
public:
    string* getName() override {return nullptr;};
    void setName(string& s) override {};

    virtual ~ObjectList() = default;
};


#endif //LLDB_DEBUGGER_FOR_WINDOWS_OBJECTLIST_H
