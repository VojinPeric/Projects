//
// Created by Vojin on 10/20/2024.
//

#include "JsonValidator.h"
#include "../OperationResult/ErrorWrongSintax.h"
#include "../OperationResult/ErrorCantOpenFile.h"
#include <fstream>

void (*JsonValidator::functionArray[10])(JsonValidator*, char) = {
        start_cond_function,
        start_name_function,
        first_letter_function,
        next_letter_function,
        sepp_function,
        value_function,
        number_function,
        end_cond_function,
        iterator_function,
        //value_with_closed_function,
        string_function
};

/*
 *      START_COND,
        START_NAME,
        FIRST_LETTER,
        NEXT_LETTER,
        SEPP,
        VALUE,
        NUMBER,
        END_COND,
        ITERATOR_COND,
        VALUE_WITH_CLOSED,
        STRING
 */

// dovrsiti
bitset<128> JsonValidator::bitsetArr[10] = {
        bitset<128>("00001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111111111111111111111111111"),
        bitset<128>("00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010111111111111111111111111111111111"),
        bitset<128>("00000111111111111111111111111110100001111111111111111111111111100000000000000000000000000001000000000000000000000000000000000000"),
        bitset<128>("00000111111111111111111111111110100001111111111111111111111111100000001111111111000000000000010000000000000000000000000000000000"),
        bitset<128>("00000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000111111111111111111111111111111111"),
        bitset<128>("00001000000000000000000000000000001010000000000000000000000000000000001111111111000000000000010111111111111111111111111111111111"),
        bitset<128>("00100000000000000000000000000000001000000000000000000000000000000000001111111111000100000000000111111111111111111111111111111111"),
        bitset<128>("00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111111111111111111111111111"),
        bitset<128>("00100000000000000000000000000000001000000000000000000000000000000000000000000000000100000000000111111111111111111111111111111111"),
        //bitset<128>("00001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111111111111111111111111111"),
        bitset<128>("11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111"),
};

void JsonValidator::start_cond_function(JsonValidator * th, char currentChar) {
    if (currentChar == '{') th->changeState(START_NAME);
}

void JsonValidator::start_name_function(JsonValidator * th, char currentChar) {
    if (currentChar == '\"') th->changeState(FIRST_LETTER);
}

void JsonValidator::first_letter_function(JsonValidator * th, char currentChar) {
    th->changeState(NEXT_LETTER);
}

void JsonValidator::next_letter_function(JsonValidator * th, char currentChar) {
    if (currentChar == '\"') th->changeState(SEPP);
}

void JsonValidator::sepp_function(JsonValidator * th, char currentChar) {
    if (currentChar == ':') th->changeState(VALUE);
}

void JsonValidator::value_function(JsonValidator * th, char currentChar) {
    if (currentChar == ']') {
        if (th->lastExecutedComa || th->openedBrackets.top()) throw ErrorWrongSintax("Char type ] in an invalid place");
        th->changeState(ITERATOR_COND);
    }
    else {
        th->lastExecutedComa = false;
        if (currentChar == '\"') th->changeState(STRING);
        else if (currentChar == '{') th->changeState(START_NAME);
        else if (currentChar >= '0' && currentChar <= '9') th->changeState(NUMBER);
    }
}

void JsonValidator::number_function(JsonValidator * th, char currentChar) {
    if (currentChar == ',') {
        if (th->openedBrackets.top()) throw ErrorWrongSintax("Char type , in an invalid place");
        th->changeState(VALUE);
        th->lastExecutedComa = true;
    }
    else if (currentChar == ']') {
        if (th->openedBrackets.top()) throw ErrorWrongSintax("Char type ] in an invalid place");
        th->changeState(ITERATOR_COND);
    }
    else if (currentChar == '}') {
        if (!th->openedBrackets.top()) throw ErrorWrongSintax("Char type } in an invalid place");
        th->changeState(ITERATOR_COND);
    }
    else if (currentChar == ' ') th->changeState(ITERATOR_COND);
}

void JsonValidator::end_cond_function(JsonValidator * th, char currentChar) {
    if (currentChar != ' ' && currentChar != '\n') {
        throw ErrorWrongSintax("Not possible having any more characters after defining the global object");
    }
}

void JsonValidator::iterator_function(JsonValidator * th, char currentChar) {
    if (currentChar == ',') {
        if (th->openedBrackets.top()) throw ErrorWrongSintax("Char type , in an invalid place");
        th->changeState(VALUE);
    }
    else if (currentChar == ']') {
        if (th->openedBrackets.top()) throw ErrorWrongSintax("Char type ] in an invalid place");
    }
    else if (currentChar == '}') {
        if (!th->openedBrackets.top()) throw ErrorWrongSintax("Char type } in an invalid place");
    }
}

/*void JsonValidator::value_with_closed_function(JsonValidator * th, char currentChar) {
    if (currentChar == '\"') th->changeState(STRING);
    else if (currentChar == '[') th->changeState(VALUE_WITH_CLOSED);
    else if (currentChar == '{') th->changeState(START_NAME);
    else if (currentChar == ']') th->changeState(ITERATOR_COND);
    else th->changeState(NUMBER);
}*/

void JsonValidator::string_function(JsonValidator* th, char currentChar) {
    if (currentChar == '\"') th->changeState(ITERATOR_COND);
}

void JsonValidator::changeState(JsonValidator::State s) {
    currentState = s;
    possibleChars.reset();
    possibleChars |= bitsetArr[s];
}

void JsonValidator::validate() {
    ifstream f;
    string line;
    bitset<128> mask;
    f.open(file);
    if (!f) throw ErrorCantOpenFile(string("cant open file named: ") + file);
    while (f) {
        getline(f, line);
        for (int i = 0; i < line.length(); i++) {
            mask = 1;
            mask <<= line[i];
            mask &= possibleChars;
            if (mask.any()) {
                try {
                    functionArray[currentState](this, line[i]);
                }
                catch (ErrorWrongSintax& e) {
                    f.close();
                    throw ErrorWrongSintax("Error in compilation on line: " + line + "; " + e.getMessage());
                }
            }
            else {
                f.close();
                throw ErrorWrongSintax("Invalid character sequence on line: " + line);
            }
            if (line[i] == '{') openedBrackets.push(true);
            else if (line[i] == '[') openedBrackets.push(false);
            else if (line[i] == '}' || line[i] == ']') openedBrackets.pop();
            if (currentState != START_COND && openedBrackets.empty()) changeState(END_COND);
        }
    }
    f.close();
    if (currentState != END_COND) throw ErrorWrongSintax("Invalid number of brackets detected on line: " + line);
}