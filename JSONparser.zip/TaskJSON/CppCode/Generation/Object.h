//
// Created by Vojin on 10/18/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_OBJECT_H
#define LLDB_DEBUGGER_FOR_WINDOWS_OBJECT_H
#include "RealNode.h"

class Object : public RealNode {
public:
    Object(Type t = NONE) : RealNode() {type = t;}
    string* getName() override {return &val;};
    void setName(string& s) override {val = s;};

    virtual ~Object() = default;
private:
    string val;
};


#endif //LLDB_DEBUGGER_FOR_WINDOWS_OBJECT_H
