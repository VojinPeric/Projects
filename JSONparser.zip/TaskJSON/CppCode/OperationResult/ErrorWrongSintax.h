//
// Created by Vojin on 10/18/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_ERRORWRONGSINTAX_H
#define LLDB_DEBUGGER_FOR_WINDOWS_ERRORWRONGSINTAX_H
#include "OperationResultError.h"

class ErrorWrongSintax : public OperationResultError {
public:
    ErrorWrongSintax(string s) : OperationResultError(s) {}

protected:
    string displayMessage() override {return "Wrong syntax in a given document";}
};


#endif //LLDB_DEBUGGER_FOR_WINDOWS_ERRORWRONGSINTAX_H
