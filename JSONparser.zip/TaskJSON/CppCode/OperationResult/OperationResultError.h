//
// Created by Vojin on 10/18/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_OPERATIONRESULTERROR_H
#define LLDB_DEBUGGER_FOR_WINDOWS_OPERATIONRESULTERROR_H
#include <exception>
#include <string>
#include <iostream>
using namespace std;

class OperationResultError : public exception {
    string s;
public:
    OperationResultError(string s) : s(s) {}

    string& getMessage() {return s;}
    virtual string getResult() {return displayMessage() + " Comment: " + s;}
protected:
    virtual string displayMessage() = 0;
};


#endif //LLDB_DEBUGGER_FOR_WINDOWS_OPERATIONRESULTERROR_H
