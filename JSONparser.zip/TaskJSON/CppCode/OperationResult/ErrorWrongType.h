//
// Created by Vojin on 10/30/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_ERRORWRONGTYPE_H
#define LLDB_DEBUGGER_FOR_WINDOWS_ERRORWRONGTYPE_H
#include "OperationResultError.h"

class ErrorWrongType : public OperationResultError {
public:
    ErrorWrongType(string s) : OperationResultError(s) {}

protected:
    string displayMessage() override {return "Wrong type in operation";}
};


#endif //LLDB_DEBUGGER_FOR_WINDOWS_ERRORWRONGTYPE_H
