//
// Created by Vojin on 10/30/2024.
//

#include "ErrorWrongType.h"
