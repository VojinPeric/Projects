//
// Created by Vojin on 10/19/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_ERRORCANTOPENFILE_H
#define LLDB_DEBUGGER_FOR_WINDOWS_ERRORCANTOPENFILE_H
#include "OperationResultError.h"


class ErrorCantOpenFile : public OperationResultError {
public:
    ErrorCantOpenFile(string s) : OperationResultError(s) {}

protected:
    string displayMessage() override {return "Can't open a file";}
};


#endif //LLDB_DEBUGGER_FOR_WINDOWS_ERRORCANTOPENFILE_H
