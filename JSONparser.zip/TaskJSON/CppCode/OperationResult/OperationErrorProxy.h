//
// Created by Vojin on 10/30/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_OPERATIONERRORPROXY_H
#define LLDB_DEBUGGER_FOR_WINDOWS_OPERATIONERRORPROXY_H
#include "OperationResultError.h"

class OperationErrorProxy : public OperationResultError {
public:
    OperationErrorProxy(string s) : OperationResultError(s) {}
    virtual string getResult() override {return getMessage();}
protected:
    string displayMessage() override {return "Wrong syntax in a given document";}
};


#endif //LLDB_DEBUGGER_FOR_WINDOWS_OPERATIONERRORPROXY_H
