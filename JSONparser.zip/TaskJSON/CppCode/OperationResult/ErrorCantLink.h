//
// Created by Vojin on 10/29/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_ERRORCANTLINK_H
#define LLDB_DEBUGGER_FOR_WINDOWS_ERRORCANTLINK_H
#include "OperationResultError.h"

class ErrorCantLink : public OperationResultError {
public:
    ErrorCantLink(string s) : OperationResultError(s) {}

protected:
    string displayMessage() override {return "Can't link expression and Json file";}
};


#endif //LLDB_DEBUGGER_FOR_WINDOWS_ERRORCANTLINK_H
