//
// Created by Vojin on 10/19/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_ERRORCANTBUILD_H
#define LLDB_DEBUGGER_FOR_WINDOWS_ERRORCANTBUILD_H
#include "OperationResultError.h"

class ErrorCantBuild : public OperationResultError{
public:
    ErrorCantBuild(string s) : OperationResultError(s) {}

protected:
    string displayMessage() override {return "Could not build the json map";}
};


#endif //LLDB_DEBUGGER_FOR_WINDOWS_ERRORCANTBUILD_H
