//
// Created by Vojin on 10/22/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_OPERATIONSEQUENCE_H
#define LLDB_DEBUGGER_FOR_WINDOWS_OPERATIONSEQUENCE_H
#include <vector>
#include <string>
using namespace std;


class OperationSequence {
public:

    enum OperationType {
        MAX,
        MIN,
        SIZE,
        PLUS,
        MINUS,
        MULTIPLICATION,
        DIVISION,
        COMA,
        OPEN_NORMAL_BRACKET,
        CLOSE_NORMAL_BRACKET,
        DOT,
        OPEN_SQUARE_BRACKET,
        CLOSE_SQUARE_BRACKET
    };

    ~OperationSequence() {for(int i = 0; i < operations.size(); i++) delete operations[i];}

    struct Operation {
        int location;
        OperationType type;
        Operation(int l, OperationType t) : location(l), type(t) {}
    };

    void addOperation(Operation* o) {operations.push_back(o);}
    Operation* getOperation(int i) {return operations[i];}
    int getLen() {return operations.size();}

    void setExpression(string& s) {expression = s;}
    string& getExpression() {return expression;}

private:
    vector<Operation*> operations;
    string expression;
};



#endif //LLDB_DEBUGGER_FOR_WINDOWS_OPERATIONSEQUENCE_H
