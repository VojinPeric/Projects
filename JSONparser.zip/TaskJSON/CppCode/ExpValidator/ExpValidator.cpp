//
// Created by Vojin on 10/21/2024.
//

#include "ExpValidator.h"
#include "../OperationResult/ErrorWrongSintax.h"

void (*ExpValidator::functionArray[11])(ExpValidator*, char) = {
        wait_for_name_num_bracket_function,
        first_letter_function,
        name_function,
        num_function,
        wait_for_operand_function,
        close_function,
        wait_for_name_num_function,
        reduced_first_letter_function,
        reduced_name_function,
        reduced_num_function,
        reduced_close_function
};
bitset<128> ExpValidator::bitsetArr[11] = {
        bitset<128>("00000111111111111111111111111110100001111111111111111111111111100000001111111111000000010001000100000000000000000000000000000000"),
        bitset<128>("00000111111111111111111111111110100001111111111111111111111111100000000000000000000000000001000000000000000000000000000000000000"),
        bitset<128>("00000111111111111111111111111110101011111111111111111111111111100000001111111111111111110000000100000000000000000000000000000000"),
        bitset<128>("00000000000000000000000000000000000000000000000000000000000000000000001111111111101111100000000100000000000000000000000000000000"),
        bitset<128>("00000000000000000000000000000000000000000000000000000000000000000000000000000000101111100000000100000000000000000000000000000000"),
        bitset<128>("00000000000000000000000000000000000010000000000000000000000000000000000000000000111111100000000100000000000000000000000000000000"),
        bitset<128>("00000111111111111111111111111110100001111111111111111111111111100000001111111111000000000001000100000000000000000000000000000000"),
        bitset<128>("00000111111111111111111111111110100001111111111111111111111111100000000000000000000000000001000000000000000000000000000000000000"),
        bitset<128>("00000111111111111111111111111110101011111111111111111111111111100000001111111111010000000000000100000000000000000000000000000000"),
        bitset<128>("00000000000000000000000000000000001000000000000000000000000000000000001111111111000000000000000100000000000000000000000000000000"),
        bitset<128>("00000000000000000000000000000000001010000000000000000000000000000000000000000000010000000000000100000000000000000000000000000000")
};
unordered_map<string, OperationSequence::OperationType> ExpValidator::functionType = {
        {"max", OperationSequence::MAX},
        {"size", OperationSequence::SIZE},
        {"min", OperationSequence::MIN}
};

void ExpValidator::run(ExpValidator *th) {
    bitset<128> mask;
    for (int i = 0; i < th->exp.size(); i++) {
        mask = 1;
        mask <<= th->exp[i];
        mask &= th->possibleChars;
        if (mask.any()) {
            try {
                functionArray[th->currentState](th, th->exp[i]);
            }
            catch (ErrorWrongSintax& e) {
                delete (*th->location);
                *(th->monitor) = new string(e.getResult());
                return;
            }
        }
        else {
            delete (*th->location);
            ErrorWrongSintax e("Invalid sequence of characters in expression");
            *(th->monitor) = new string(e.getResult());
            return;
        }
    }
    if (th->holder.size()) th->newExpression += th->holder;
    (*(th->location))->setExpression(th->newExpression);
    *(th->monitor) = nullptr;
}

void ExpValidator::wait_for_name_num_bracket_function(ExpValidator * th, char c) {
    if (c == '(') {
        th->brackets.push(OperationSequence::OPEN_NORMAL_BRACKET);
        (*th->location)->addOperation(new OperationSequence::Operation(th->newExpression.size(), OperationSequence::OPEN_NORMAL_BRACKET));
    }
    else if(isFirstLetter(c)) {
        th->changeState(NAME);
        th->holder += c;
    }
    else if(isNumber(c)) {
        th->changeState(NUM);
        th->newExpression += c;
    }
}

void ExpValidator::first_letter_function(ExpValidator * th, char c) {
    th->changeState(NAME);
    th->holder += c;
}

void ExpValidator::name_function(ExpValidator * th, char c) {
    if (isName(c)) {
        th->holder += c;
    }
    else {
        if (c == '(') {
            auto search = th->functionType.find(th->holder);
            if (search == th->functionType.end()) {
                throw ErrorWrongSintax("Non valid function call");
            }
            th->brackets.push(search->second);
            th->changeState(WAIT_FOR_NAME_NUM_BRACKET);
            (*th->location)->addOperation(new OperationSequence::Operation(th->newExpression.size(), search->second));
        }
        else {
            th->newExpression += th->holder;
            if (c == '.') {
                th->changeState(FIRST_LETTER);
                th->newExpression += c;
            }
            else if (c == '[') {
                th->brackets.push(OperationSequence::OPEN_SQUARE_BRACKET);
                th->changeState(WAIT_FOR_NAME_NUM);
                th->newExpression += c;
            }
            else if (c == ' ') th->changeState(WAIT_FOR_OPERAND);
            else wait_for_operand_function(th, c);
        }
        th->holder.clear();
    }
    
}

void ExpValidator::num_function(ExpValidator * th, char c) {
    if (c == ' ') th->changeState(WAIT_FOR_OPERAND);
    else if (isNumber(c)) th->newExpression += c;
    else wait_for_operand_function(th, c);
}

void ExpValidator::wait_for_operand_function(ExpValidator * th, char c) {
    if (isBinaryOperation(c)) {
        th->changeState(WAIT_FOR_NAME_NUM_BRACKET);
        if (c == '+')
            (*th->location)->addOperation(new OperationSequence::Operation(th->newExpression.size(), OperationSequence::PLUS));
        else if (c == '-')
            (*th->location)->addOperation(new OperationSequence::Operation(th->newExpression.size(), OperationSequence::MINUS));
        else if (c == '*')
            (*th->location)->addOperation(new OperationSequence::Operation(th->newExpression.size(), OperationSequence::MULTIPLICATION));
        else
            (*th->location)->addOperation(new OperationSequence::Operation(th->newExpression.size(), OperationSequence::DIVISION));
    }
    else if (c == ',') {
        th->comaOperation();
    }
    else if (c == ')') {
        th->closedBracketOperation();
    }
}

void ExpValidator::close_function(ExpValidator * th, char c) {
    if (c == '.') {
        th->changeState(FIRST_LETTER);
        th->newExpression += c;
    }
    else if (c == ' ') th->changeState(WAIT_FOR_OPERAND);
    else if (c == '[') {
        th->brackets.push(OperationSequence::OPEN_SQUARE_BRACKET);
        th->changeState(WAIT_FOR_NAME_NUM);
        th->newExpression += c;
    }
    else wait_for_operand_function(th, c);
}

void ExpValidator::wait_for_name_num_function(ExpValidator * th, char c) {
    if(isFirstLetter(c)) {
        th->changeState(REDUCED_NAME);
        th->newExpression += c;
    }
    else if(isNumber(c)) {
        th->changeState(REDUCED_NUM);
        th->newExpression += c;
    }
}

void ExpValidator::reduced_first_letter_function(ExpValidator * th, char c) {
    th->changeState(REDUCED_NAME);
    th->newExpression += c;
}

void ExpValidator::reduced_name_function(ExpValidator * th, char c) {
    if (c == ' ') th->changeState(REDUCED_CLOSE);
    else {
        th->newExpression += c;
        if (c == '.') {
            th->changeState(REDUCED_FIRST_LETTER);
        }
        else if (c == '[') {
            th->changeState(WAIT_FOR_NAME_NUM);
            th->brackets.push(OperationSequence::OPEN_SQUARE_BRACKET);
        }
        else if (c == ']') {
            th->brackets.pop();
            if (!th->brackets.empty() && th->brackets.top() == OperationSequence::OPEN_SQUARE_BRACKET) th->changeState(REDUCED_CLOSE);
            else th->changeState(CLOSE);
        }
    }
}

void ExpValidator::reduced_num_function(ExpValidator * th, char c) {
    if (c == ' ') th->changeState(REDUCED_CLOSE);
    else {
        th->newExpression += c;
        if (c == ']') {
            th->brackets.pop();
            if (!th->brackets.empty() && th->brackets.top() == OperationSequence::OPEN_SQUARE_BRACKET) th->changeState(REDUCED_CLOSE);
            else th->changeState(CLOSE);
        }
    }
}

void ExpValidator::reduced_close_function(ExpValidator * th, char c) {
    if (c == '.') {
        th->changeState(REDUCED_FIRST_LETTER);
        th->newExpression += c;
    }
    else if (c == ']') {
        th->brackets.pop();
        if (th->brackets.empty() || th->brackets.top() != OperationSequence::OPEN_SQUARE_BRACKET) th->changeState(CLOSE);
        th->newExpression += c;
    }
    else if (c == '[') {
        th->changeState(WAIT_FOR_NAME_NUM);
        th->brackets.push(OperationSequence::OPEN_SQUARE_BRACKET);
        th->newExpression += c;
    }
}

void ExpValidator::changeState(ExpValidator::State s) {
    currentState = s;
    possibleChars.reset();
    possibleChars |= bitsetArr[s];
}

bool ExpValidator::isFirstLetter(char c) {
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '$' || c == '_') return true;
    return false;
}

bool ExpValidator::isName(char c) {
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_') return true;
    return false;
}

bool ExpValidator::isNumber(char c) {
    if ((c >= '0') && (c <= '9')) return true;
    return false;
}

bool ExpValidator::isBinaryOperation(char c) {
    if (c == '+' || c == '-' || c == '/' || c == '*') return true;
    return false;
}

void ExpValidator::comaOperation() {
    if (brackets.empty() || (brackets.top() != OperationSequence::MAX && brackets.top() != OperationSequence::MIN))
        throw ErrorWrongSintax("Invalid , sign");
    changeState(WAIT_FOR_NAME_NUM_BRACKET);
    (*location)->addOperation(new OperationSequence::Operation(newExpression.size(), OperationSequence::COMA));
}

void ExpValidator::closedBracketOperation() {
    if (brackets.empty() || brackets.top() == OperationSequence::OPEN_SQUARE_BRACKET) throw ErrorWrongSintax("Invalid ( sign");
    brackets.pop();
    changeState(WAIT_FOR_OPERAND);
    (*location)->addOperation(new OperationSequence::Operation(newExpression.size(), OperationSequence::CLOSE_NORMAL_BRACKET));
}
