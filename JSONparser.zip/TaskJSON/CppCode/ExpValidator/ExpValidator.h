//
// Created by Vojin on 10/21/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_EXPVALIDATOR_H
#define LLDB_DEBUGGER_FOR_WINDOWS_EXPVALIDATOR_H
#include <unordered_map>
#include <thread>
#include <bitset>
#include <stack>
#include "../OperationResult/OperationResultError.h"
#include "../OperationSequence/OperationSequence.h"
using namespace std;

class ExpValidator {
public:
    ExpValidator(const char* expression, string** monitor, OperationSequence** location) : exp(expression),
    monitor(monitor), location(location), possibleChars(bitsetArr[0]) {
        *location = new OperationSequence();
        th = new thread(run, this);
    }
    ~ExpValidator() {delete th;}

    void join() {
        th->join();
    }

private:
    enum State {
        WAIT_FOR_NAME_NUM_BRACKET,
        FIRST_LETTER,
        NAME,
        NUM,
        WAIT_FOR_OPERAND,
        CLOSE,
        WAIT_FOR_NAME_NUM,
        REDUCED_FIRST_LETTER,
        REDUCED_NAME,
        REDUCED_NUM,
        REDUCED_CLOSE
    };



    static void run(ExpValidator*);

    static void wait_for_name_num_bracket_function(ExpValidator*, char);
    static void first_letter_function(ExpValidator*, char);
    static void name_function(ExpValidator*, char);
    static void num_function(ExpValidator*, char);
    static void wait_for_operand_function(ExpValidator*, char);
    static void close_function(ExpValidator*, char);
    static void wait_for_name_num_function(ExpValidator*, char);
    static void reduced_first_letter_function(ExpValidator*, char);
    static void reduced_name_function(ExpValidator*, char);
    static void reduced_num_function(ExpValidator*, char);
    static void reduced_close_function(ExpValidator*, char);

    static void (*functionArray[11])(ExpValidator*, char);
    static bitset<128> bitsetArr[11];
    static unordered_map<string, OperationSequence::OperationType> functionType;

    void changeState(State s);
    void comaOperation();
    void closedBracketOperation();

    static bool isFirstLetter(char c);
    static bool isName(char c);
    static bool isNumber(char c);
    static bool isBinaryOperation(char c);


    stack<OperationSequence::OperationType> brackets;
    State currentState = WAIT_FOR_NAME_NUM_BRACKET;
    bitset<128> possibleChars;
    string holder;
    string newExpression;
    string exp;
    thread* th;
    OperationSequence** location;
    string** monitor;

};


#endif //LLDB_DEBUGGER_FOR_WINDOWS_EXPVALIDATOR_H
