//
// Created by Vojin on 10/19/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_HASHTREE_H
#define LLDB_DEBUGGER_FOR_WINDOWS_HASHTREE_H
#include <string>
using namespace std;
class RealNode;

class HashTree {
public:
    HashTree() { initRoot(); };
    ~HashTree() { deleteTree(root); };

    RealNode* getObject(string&, RealNode*);
    RealNode* getRoot() {return root;};
    void printTree(RealNode* curr, const char* file);

private:
    RealNode* root;
    void initRoot();
    void deleteTree(RealNode* curr);
};


#endif //LLDB_DEBUGGER_FOR_WINDOWS_HASHTREE_H
