//
// Created by Vojin on 10/19/2024.
//

#include "Hasher.h"

RealNode *Hasher::getHash() {
    return current;
}

bool Hasher::findNode(string &path) {
    RealNode* n = tree->getObject(path, current);
    if (!n) return false;
    current = n;
    return true;
}
