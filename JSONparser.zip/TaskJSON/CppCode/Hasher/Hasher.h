//
// Created by Vojin on 10/19/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_HASHER_H
#define LLDB_DEBUGGER_FOR_WINDOWS_HASHER_H
#include <string>
#include "HashTree.h"
using namespace std;

class Hasher {
public:
    Hasher(HashTree* tree) : tree(tree), current(tree->getRoot()) {}
    Hasher(Hasher* h) : tree(h->tree), current(h->tree->getRoot()) {}

    RealNode* getHash();
    bool findNode(string& path);

private:
    RealNode* current;
    HashTree* tree;
};


#endif //LLDB_DEBUGGER_FOR_WINDOWS_HASHER_H
