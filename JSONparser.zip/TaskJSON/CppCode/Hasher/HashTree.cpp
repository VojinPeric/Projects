//
// Created by Vojin on 10/19/2024.
//

#include "HashTree.h"
#include <stdexcept>
#include <iostream>
#include "../Generation/Object.h"

RealNode *HashTree::getObject(string & s, RealNode * n) {
    if (n->getType() == Node::OBJECT_LIST) {
        int num;
        try {
            num = std::stoi(s);
        }
        catch (const std::invalid_argument& e) {
            return nullptr;
        }
        return n->getNext(num);
    }
    else if (n->getType() == Node::OBJECT) {
        if (s == *n->getNext(0)->getName())  return n->getNext(0);
        return nullptr;
    }
    return nullptr;
}

void HashTree::printTree(RealNode* curr, const char* file)
{
    cout << curr->getValue(file) << endl;
    if (!curr->len()) {
        return;
    }
    for (int i = 0; i < curr->len(); i++) {
        printTree(curr->getNext(i), file);
    }
}

void HashTree::initRoot() {
    root = new Object(Node::OBJECT);
}

void HashTree::deleteTree(RealNode* curr) {
    if (!curr->len()) {
        delete curr;
        return;
    }
    for (int i = 0; i < curr->len(); i++) {
        deleteTree(curr->getNext(i));
    }
    delete curr;
}
