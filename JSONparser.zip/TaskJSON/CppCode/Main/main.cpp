#include <iostream>
#include <fstream>
#include <sstream>
#include "../Generation/JsonGenerator.h"
#include "../ExpValidator/ExpValidator.h"
#include "../Evaluater/Calculator.h"

using namespace std;
std::string cleanString(const std::string& input) {
    std::string result;
    std::istringstream stream(input);
    std::string word;

    // Read words from the stream, separating by whitespace
    while (stream >> word) {
        if (!result.empty()) {
            result += ' '; // Add a space before the next word
        }
        result += word; // Append the word
    }

    return result; // Return the cleaned string
}

int main() {
    // json file
    const char* fileName = "../../TestFiles/userTest.json";

    // expression file
    const char* conditionFile = "../../TestFiles/userExpression.txt";

    // result file
    const char* result = "../../TestFiles/jsonResult.txt";

    HashTree** map = new HashTree * ;

    string** jsonM = new string*;
    JsonGenerator* gen = new JsonGenerator(jsonM, fileName, map);

    vector<string**> exprMs;
    vector<OperationSequence**> ops;
    vector<ExpValidator*> exps;
    ifstream expFile;
    expFile.open(conditionFile);
    if (!expFile) {
        gen->join();
        if (*jsonM) {
            cout << **jsonM << endl;
            delete* jsonM;
            delete jsonM;
            return 1;
        }
        delete* jsonM;
        delete jsonM;
        cout << "Could not open expression file" << endl;
        return 1;
    }

    int exprLen = 0;
    while (expFile) {
        string line;
        getline(expFile, line);
        if (line == "") break;
        exprMs.push_back(new string*);
        ops.push_back(new OperationSequence*);
        exps.push_back(new ExpValidator(line.c_str(), exprMs[exprLen], ops[exprLen]));
        exprLen++;
    }
    expFile.close();

    gen->join();
    if (*jsonM) {
        cout << **jsonM << endl;
        delete* jsonM;
        delete jsonM;
        return 1;
    }
    delete* jsonM;
    delete jsonM;

    //(*map)->printTree((*map)->getRoot(), fileName);

    bool failed = false;
    for (int i = 0; i < exprLen; i++) {
        exps[i]->join();
        if (*(exprMs[i])) {
            cout << **(exprMs[i]) << endl;
            failed = true;
        }
        delete* (exprMs[i]);
        delete (exprMs[i]);
    }
    if (failed) return 1;

    ofstream resultFile(result);

    for (int i = 0; i < exprLen; i++) {
        Calculator* c = new Calculator(*(ops[i]), *map, fileName);
        string ret;
        try {
            ret = c->calculate();
            cout << cleanString(ret) << endl << "---" << endl;
            resultFile << cleanString(ret) << endl << "---" << endl;
        }
        catch (OperationResultError& e) {
            cout << e.getResult() << endl;
            failed = true;
        }
        delete c;
        delete* ops[i];
        delete ops[i];
    }
    delete* map;
    delete map;
    if (failed) return 1;
}
