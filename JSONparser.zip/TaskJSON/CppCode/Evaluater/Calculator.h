//
// Created by Vojin on 10/29/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_CALCULATOR_H
#define LLDB_DEBUGGER_FOR_WINDOWS_CALCULATOR_H
#include "../OperationSequence/OperationSequence.h"
#include "ExprEvaluator.h"

class Calculator {
public:

    Calculator(OperationSequence* operations, HashTree* tree, const char* file) : operations(operations), tree(tree), file(file) {}
    string calculate();

    ~Calculator();

private:
    struct Operand {
        string** monitor;
        Node** result;
        ExprEvaluator* thread;
    };

    struct Operators {
        OperationSequence::OperationType type;
        int parametarNumber;
    };

    struct Priority {
        int ipr;
        int spr;
        int params;
    };

    static Node* (*functionArray[7])(Calculator*);
    static Priority priorities[10];

    static Node* max_function(Calculator*);
    static Node* min_function(Calculator*);
    static Node* size_function(Calculator*);
    static Node* plus_function(Calculator*);
    static Node* minus_function(Calculator*);
    static Node* multiplication_function(Calculator*);
    static Node* devision_function(Calculator*);

    void addToOperands(int start, int end);
    void deleteArrayValue(int i);
    void deleteParams();
    bool doOperation();
    Node* doMaxMin(bool);

    Node** retValue;
    HashTree* tree;
    OperationSequence* operations;
    vector<Operand> operands;
    vector<Node*> params;
    stack<Operators> currentOperators;
    stack<int> currentOperands;
    const char* file;
    int currentOperation;
    int savedIndexForDelete = -1;
};


#endif //LLDB_DEBUGGER_FOR_WINDOWS_CALCULATOR_H
