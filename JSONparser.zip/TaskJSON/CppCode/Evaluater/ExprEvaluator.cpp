//
// Created by Vojin on 10/29/2024.
//

#include "ExprEvaluator.h"
#include "../Generation/NumberNode.h"
#include "../OperationResult/ErrorCantOpenFile.h"
#include "../OperationResult/ErrorCantLink.h"
#include "../Generation/RealNode.h"
#include <fstream>

void ExprEvaluator::run(ExprEvaluator * th) {
    int i = th->start;
    Node* n = th->calculateExpression(i);
    if (!n) {
        (*th->monitor) = new string(ErrorCantLink("No object found with given path").getResult());
        (*th->retValue) = nullptr;
        return;
    }
    (*th->monitor) = nullptr;
    (*th->retValue) = n;
}

Node* ExprEvaluator::calculateExpression(int& i)
{
    Hasher* hash = new Hasher(hasher);
    string holder;
    bool isNum = false;
    if (expr[i] >= '0' && expr[i] <= '9') isNum = true;
    while (i < end && expr[i] != ']') {
        if (expr[i] != '[' && expr[i] != '.') holder += expr[i];
        else if (expr[i] == '.') {
            if (!hash->findNode(holder)) {
                delete hash;
                return nullptr;
            }
            holder.clear();
        }
        else {
            if (!hash->findNode(holder)) {
                delete hash;
                return nullptr;
            }
            Node* ret = calculateExpression(++i);
            if (!ret || ret->getType() != Node::NUMBER) {
                delete hash;
                return nullptr;
            }
            holder = ret->getValue(file);
            if (ret->canDelete()) delete ret;
        }
        i++;
    }
    Node* n;
    if (isNum) n = new NumberNode(holder);
    else {
        if (!hash->findNode(holder)) {
            delete hash;
            return nullptr;
        }
        n = hash->getHash();
    }
    delete hash;
    return n;
}
