//
// Created by Vojin on 10/29/2024.
//

#include "Calculator.h"
#include "../OperationResult/OperationErrorProxy.h"
#include "../OperationResult/ErrorWrongType.h"
#include "../Generation/NumberNode.h"
#include "../Generation/RealNode.h"

Node * (*Calculator::functionArray[7])(Calculator*) = {
        max_function,
        min_function,
        size_function,
        plus_function,
        minus_function,
        multiplication_function,
        devision_function
};

Calculator::Priority Calculator::priorities[10] = {
        {6, 0, 1},
        {6, 0, 1},
        {6, 0, 1},
        {2, 2, 2},
        {2, 2, 2},
        {3, 3, 2},
        {3, 3, 2},
        {1, 0, 0},
        {6, 0, 0},
        {0, 0, 0}
};

string Calculator::calculate() {
    if (!operations->getLen()) {
        if (operations->getExpression().size()) addToOperands(0, operations->getExpression().size());
    }
    else {
        if (operations->getOperation(0)->location - 0) addToOperands(0, operations->getOperation(0)->location);
        for (int i = 1; i < operations->getLen(); i++) {
            if (operations->getOperation(i)->location - operations->getOperation(i - 1)->location) addToOperands(
                    operations->getOperation(i - 1)->location, operations->getOperation(i)->location);
        }
        if (operations->getExpression().size() - operations->getOperation(operations->getLen() - 1)->location)
            addToOperands( operations->getOperation(operations->getLen() - 1)->location, operations->getExpression().size());
    }
    int start = 0;
    currentOperation = 0;
    for (int i = 0; i < operations->getLen(); i++) {
        OperationSequence::Operation* op = operations->getOperation(i);
        if (op->location - start) {
            currentOperands.push(currentOperation++);
            start = op->location;
        }
        while (!currentOperators.empty() && priorities[op->type].ipr <= priorities[currentOperators.top().type].spr) {
            if (doOperation()) break;
        }
        if (op->type == OperationSequence::COMA) {
            if (currentOperators.top().type == OperationSequence::MAX || currentOperators.top().type == OperationSequence::MIN) {
                currentOperators.top().parametarNumber++;
            }
        }
        else if (op->type != OperationSequence::CLOSE_NORMAL_BRACKET) currentOperators.push({op->type, priorities[op->type].params});
    }
    if (operations->getExpression().size() - start) currentOperands.push(currentOperation++);
    while (!currentOperators.empty()) {
        doOperation();
    }
    if (operands[currentOperands.top()].thread) {
        operands[currentOperands.top()].thread->join();
        if (*operands[currentOperands.top()].monitor) {
            savedIndexForDelete = currentOperands.top();
            currentOperands.pop();
            throw OperationErrorProxy(**operands[savedIndexForDelete].monitor);
        }
    }
    string ret = (*operands[currentOperands.top()].result)->getValue(file);
    currentOperands.pop();
    return ret;
}



Node *Calculator::max_function(Calculator * calc) {
    return calc->doMaxMin(true);
}

Node *Calculator::min_function(Calculator * calc) {
    return calc->doMaxMin(false);
}

Node *Calculator::size_function(Calculator * calc) {
    if (calc->params[0]->getType() == Node::OBJECT_LIST) {
        return new NumberNode(to_string(calc->params[0]->len()));
    }
    if (calc->params[0]->getType() == Node::STRING) {
        return new NumberNode(to_string(calc->params[0]->getValue(calc->file).size() - 2));
    }
    if (calc->params[0]->getType() == Node::OBJECT) {
        return new NumberNode("1");
    }
    throw ErrorWrongType("Size function must contain only 1 element of type list or string");
}

Node *Calculator::plus_function(Calculator * calc) {
    if (!(calc->params[0]->getType() == Node::NUMBER && calc->params[1]->getType() == Node::NUMBER)) throw ErrorWrongType("+ operation needs 2 numbers");
    return new NumberNode(to_string(stoi(calc->params[0]->getValue(calc->file)) + stoi(calc->params[1]->getValue(calc->file))));
}

Node *Calculator::minus_function(Calculator * calc) {
    if (!(calc->params[0]->getType() == Node::NUMBER && calc->params[1]->getType() == Node::NUMBER)) throw ErrorWrongType("- operation needs 2 numbers");
    return new NumberNode(to_string(stoi(calc->params[1]->getValue(calc->file)) - stoi(calc->params[0]->getValue(calc->file))));
}

Node *Calculator::multiplication_function(Calculator * calc) {
    if (!(calc->params[0]->getType() == Node::NUMBER && calc->params[1]->getType() == Node::NUMBER)) throw ErrorWrongType("* operation needs 2 numbers");
    return new NumberNode(to_string(stoi(calc->params[0]->getValue(calc->file)) * stoi(calc->params[1]->getValue(calc->file))));
}

Node *Calculator::devision_function(Calculator * calc) {
    if (!(calc->params[0]->getType() == Node::NUMBER && calc->params[1]->getType() == Node::NUMBER)) throw ErrorWrongType("/ operation needs 2 numbers");
    return new NumberNode(to_string(stoi(calc->params[1]->getValue(calc->file)) / stoi(calc->params[0]->getValue(calc->file))));
}

void Calculator::addToOperands(int start, int end) {
    string** monitor = new string*;
    Node** node = new Node*;
    operands.push_back({monitor, node, new ExprEvaluator(operations->getExpression(),
                                                         tree, start, end,node, monitor, file)});
}

void Calculator::deleteArrayValue(int i) {
    if (operands[i].thread) delete operands[i].thread;
    if (*operands[i].monitor) delete *operands[i].monitor;
}

void Calculator::deleteParams() {
    for (int i = 0; i < params.size(); i++) if (params[i]->canDelete()) delete params[i];
    params.clear();
}

bool Calculator::doOperation() {
    if (currentOperators.top().type == OperationSequence::OPEN_NORMAL_BRACKET) {
        currentOperators.pop();
        return true;
    }
    int index;
    for (int j = 0; j < currentOperators.top().parametarNumber; j++) {
        index = currentOperands.top();
        if (operands[index].thread) operands[index].thread->join();
        if (*operands[index].monitor) {
            savedIndexForDelete = index;
            currentOperands.pop();
            throw OperationErrorProxy(**operands[index].monitor);
        }
        currentOperands.pop();
        params.push_back(*operands[index].result);
        deleteArrayValue(index);
    }
    *operands[index].result = functionArray[currentOperators.top().type](this);
    *operands[index].monitor = nullptr;
    operands[index].thread = nullptr;
    currentOperands.push(index);
    deleteParams();
    if (!priorities[currentOperators.top().type].spr) {
        currentOperators.pop();
        return true;
    }
    currentOperators.pop();
    return false;
}

Calculator::~Calculator() {
    if (savedIndexForDelete >= 0) {
        delete operands[savedIndexForDelete].thread;
        delete* operands[savedIndexForDelete].monitor;
        if (*operands[savedIndexForDelete].result && (*operands[savedIndexForDelete].result)->canDelete())
            delete (*operands[savedIndexForDelete].result);
    }
    for (int i = currentOperation; i < operands.size(); i++) {
        operands[i].thread->join();
        delete operands[i].thread;
        delete *operands[i].monitor;
    }
    while (!currentOperands.empty()) {
        if (operands[currentOperands.top()].thread) {
            operands[currentOperands.top()].thread->join();
            delete operands[currentOperands.top()].thread;
            delete *operands[currentOperands.top()].monitor;
        }
        if (*operands[currentOperands.top()].result && (*operands[currentOperands.top()].result)->canDelete())
            delete (*operands[currentOperands.top()].result);
        currentOperands.pop();
    }
    deleteParams();
    for (int i = 0; i < operands.size(); i++) {
        delete operands[i].monitor;
        delete operands[i].result;
    }
}

Node *Calculator::doMaxMin(bool maxOp) {
    if (params.size() == 1 && params[0]->getType() == Node::OBJECT_LIST) {
        int i = 0;
        int max = 0;
        int min = INT_MAX;
        if (params[0]->getNext(i) == nullptr) {
            throw ErrorWrongType("Can't have max of an empty list");
        }
        while (params[0]->getNext(i) != nullptr) {
            if (params[0]->getNext(i)->getType() != Node::NUMBER) {
                throw ErrorWrongType("Can't have max of a list with different types than number");
            }
            int curr = stoi(params[0]->getNext(i)->getValue(file));
            if (maxOp && curr > max) max = curr;
            else if (!maxOp && curr < min) min = curr;
            i++;
        }
        if (maxOp) return new NumberNode(to_string(max));
        else return new NumberNode(to_string(min));
    }
    else if (params.size() == 1 && params[0]->getType() == Node::NUMBER) {
        return new NumberNode(params[0]->getValue(file));
    }
    else if (params.size() > 1) {
        int max = 0;
        int min = INT_MAX;
        for (int i = 0; i < params.size(); i++) {
            if (params[i]->getType() != Node::NUMBER) {
                throw ErrorWrongType("if number of max parameters is > 0 then all of them must be numbers");
            }
            if (maxOp && stoi(params[i]->getValue(file)) > max) max = stoi(params[i]->getValue(file));
            else if (!maxOp && stoi(params[i]->getValue(file)) < min) min = stoi(params[i]->getValue(file));
        }
        if (maxOp) return new NumberNode(to_string(max));
        else return new NumberNode(to_string(min));
    }
    throw ErrorWrongType("Invalid type for max operation");
}
