//
// Created by Vojin on 10/29/2024.
//

#ifndef LLDB_DEBUGGER_FOR_WINDOWS_EXPREVALUATOR_H
#define LLDB_DEBUGGER_FOR_WINDOWS_EXPREVALUATOR_H
#include <string>
#include "../Hasher/Hasher.h"
#include <stack>
#include <thread>
using namespace std;
class Node;

class ExprEvaluator {
public:

    ExprEvaluator(string& expr, HashTree* tree, int start, int end, Node** retValue, string** monitor, const char* file) : expr(expr), start(start),
    end(end), retValue(retValue), file(file), monitor(monitor) {
        hasher = new Hasher(tree);
        th = new thread(run, this);
    }

    ~ExprEvaluator() {
        delete hasher;
        delete th;
        while (!stack.empty()) {
            delete stack.top();
            stack.pop();
        }
    }

    void join() {
        th->join();
    }

private:
    static void run(ExprEvaluator*);
    Node* calculateExpression(int& i);

    int start, end;
    string& expr;
    Hasher* hasher;
    thread* th;
    Node** retValue;
    const char* file;
    string** monitor;
    stack<Hasher*> stack;
};


#endif //LLDB_DEBUGGER_FOR_WINDOWS_EXPREVALUATOR_H
