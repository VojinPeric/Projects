This folder consists of 3 files:
CppCode
PythonTest
TestFiles

CppCode is a full project that represents the JSON parser and validator, expression validator and evaluation in regards to the parsed JSON. The solution validates and parses the JSON file and expressions in multiple threads, after which it calculates and converts JSON expressions also in multiple threads. The operations implemented are as follows:
- Binary operations:
+, -, *, /
- Functions:
max, min, size
- brackets:
(, )

There are some restrictions in the solution compared to a normal JSON parser:
there must be one global object,
only types except objects and lists are strings and numbers,
its not possible to have more than one object inside another object ({"a" : "b", "c"} not allowed, {"a": ["b", "c"]} is allowed)
nesting of operations in a expression is possible except in an index operator for a json expression
(a.b[a + b] is not allowed, a.b[a[0]] is allowed)

Code is build and tested as follows:
In TestFiles directory there are two files named "userTest.json" and "userExpression.txt". These 2 files contain a json file which is parsed and expressions which are calculated (multiple expressions possible, one expression per row in file). User needs to put his own test or use the already made test cases and connect the relative paths to the files in CppCode/Main/main.cpp and execute the code. After that if not already created there should be a jsonResult.txt file which are the results on given queries separated by "---". After that go to the PythonTest folder where you can find the test script. When you open it there are two relative paths that need to be adjusted; the json file and the result file. In this file you can also see the expr array which you must change if you change the expressions file (this array represents the same expressions from the file just written with python syntax, if adding new expressions chat Gpt can easily make the python version). Finally this test script can only test number return values for the expressions (returns true if the c++ code works), everything else can be compared just by checking the jsonResult file and python console output (I can't test anything else by script because it is not guaranteed that it would be in the same format). As I have mentioned there is already a detailed test case that goes through different kinds of expressions, but a user is free to add his own test cases.

If there are any further questions you may write me on my email: vojinperic9@gmail.com
Kind regards, Vojin Peric