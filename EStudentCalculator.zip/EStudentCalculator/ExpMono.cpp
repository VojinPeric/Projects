//
// Created by Vojin on 3/13/2024.
//

#include "ExpMono.h"

ExpMono::~ExpMono() = default;
