//
// Created by Vojin on 3/13/2024.
//

#include "ExpGeneratorMultiple.h"

ExpGeneratorMultiple::ExpGeneratorMultiple(std::string *sign, int len) {
    for (int i = 0; i < len; i++) signs.insert(sign[i]);
}

std::string ExpGeneratorMultiple::generateExpr(std::string &expr) {
    initValues();
    for (int i = 0; i < expr.length(); i++) {
        if(updateHolderAndCheckNumber(expr[i])) continue;
        if(signs.find(holder) != signs.end() || isNumber) {
            if (isNumber) holder.pop_back();
            retData += holder + operand;
            restartHolderAndCode();
            if(checkCurrAndResetNumber()) continue;
        }
        code = appendOperatorId(expr[i], code);
        if (!code) throw -1;
        entry = getOperatorTableIndex(code);
        if (entry < 0) continue;
        else entryPrio = operatorTablePrioEntry[entry];
        restartHolderAndCode();
        if (curr != prioTable[entryPrio].operandBefore) throw -1;
        while (!operatorInput.empty()) {
            prioTop = prioTable[operatorTablePrioEntry[operatorInput.top()]].spr;
            if (prioTable[entryPrio].ipr <= prioTop) {
                curr = true;
                popItems(input);
                retData += std::to_string(input) + operatorNumber;
            }
            else break;
        }
        if (expr[i] != ')' && expr[i] != ',') {
            checkConditionsOnPush();
            operatorInput.push(entry);
        }
        else {
            if (operatorInput.empty()) throw -1;
            if (expr[i] == ',') comaCheck();
            else {
                popItems(input);
                if (!prioTable[operatorTablePrioEntry[input]].openBracket) throw -1;
                if (--numOpenBracket < 0) throw -1;

                if (prioTable[operatorTablePrioEntry[input]].openComa) {
                    if (!comaStack.top()) throw -1;
                    comaStack.pop();
                }
                if (input == openBrackerEntry) continue;
                retData += std::to_string(input) + operatorNumber;
            }
        }
    }
    afterLoopAdjustments();
    while (!operatorInput.empty()) {
        popItems(input);
        retData += std::to_string(input) + operatorNumber;
    }
    return retData;
}

void ExpGeneratorMultiple::popItems(int& entry) {
    entry = operatorInput.top();
    operatorInput.pop();
}