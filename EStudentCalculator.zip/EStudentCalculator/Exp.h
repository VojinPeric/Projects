//
// Created by Vojin on 3/12/2024.
//

#ifndef PERFECTHASHTEST_EXP_H
#define PERFECTHASHTEST_EXP_H
#include <string>
#include "typeDeclarations.h"

class Exp {
public:
    virtual ~Exp() = 0;

protected:
    constexpr static int lengthOfOperatorTable = 10;
    constexpr static char operand = 'O';
    constexpr static char operatorNumber = 'D';
};


#endif //PERFECTHASHTEST_EXP_H
