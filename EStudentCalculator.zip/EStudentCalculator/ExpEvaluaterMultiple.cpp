//
// Created by Vojin on 3/12/2024.
//

#include "ExpEvaluaterMultiple.h"


ExpEvaluaterMultiple::ExpEvaluaterMultiple(std::string* sign, double* values, int len) {
    for (int i = 0; i < len; i++) symbolTable.insert(std::pair<std::string, double>(sign[i], values[i]));
}

double ExpEvaluaterMultiple::evaluateExpr(std::string &expr) {
    for (int i = 0; i < expr.length(); i++) {
        if (expr[i] == operand) {
            if (symbolTable.find(holder) != symbolTable.end()) {
                value = symbolTable[holder];
            }
            else {
                value = std::strtod(holder.c_str(), nullptr);
            }
            operands.push(value);
            holder = "";
            continue;
        }
        if (expr[i] == operatorNumber) {
            key = atoi(holder.c_str());
            functionTable[key](operands);
            holder = "";
            continue;
        }
        holder += expr[i];
    }
    value = operands.top();
    operands.pop();
    return value;
}
