//
// Created by Vojin on 3/30/2024.
//

#ifndef PERFECTHASHTEST_READEXCEPTION_H
#define PERFECTHASHTEST_READEXCEPTION_H
#include <exception>


#endif //PERFECTHASHTEST_READEXCEPTION_H
