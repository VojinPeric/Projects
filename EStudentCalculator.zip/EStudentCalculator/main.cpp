#include <iostream>
typedef unsigned long long uint64;
const unsigned int offset = 39;
const unsigned int length = 10;

int main() {
    uint64 arr[length], helpNum;
    std::string s;
    for (int i = 0; i < length; i++) {
        std::cin >> s;
        helpNum = 0;
        for (int j = 0; j < s.length(); j++) {
            if (j) helpNum <<= 6;
            helpNum += s[j] - offset;
        }
        arr[i] = helpNum;
    }
    for (int i = 0; i < length; i++) {
        std::cout << arr[i] << std::endl;
    }

    uint64* hashMap;
    int i = length;
    uint64 z = 1;
//  (K mod n)
    while (true) {
        hashMap = new uint64 [i];
        for (int j = 0; j < i; j++) hashMap[j] = 0;
        for (int j = 0; j < length; j++) {
            int key = (arr[j] + arr[j] / z) % i;
            if (hashMap[key]) break;
            hashMap[key] = arr[j];
            if (j == length-1) goto finish;
        }
        delete[] hashMap;
        z++;
    }
    finish:
    for (int j = 0; j < i; j++) {
        std::cout << hashMap[j] << std::endl;
    }
    std::cout << z;

    return 0;
}
