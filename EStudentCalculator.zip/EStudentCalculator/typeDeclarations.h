//
// Created by Vojin on 3/12/2024.
//

#ifndef PERFECTHASHTEST_TYPEDECLARATIONS_H
#define PERFECTHASHTEST_TYPEDECLARATIONS_H
#include <stack>
typedef unsigned long long uint64;
typedef void (*funcP)(std::stack<double>&);
typedef double (*funcP2)(double*, int);
#endif //PERFECTHASHTEST_TYPEDECLARATIONS_H
