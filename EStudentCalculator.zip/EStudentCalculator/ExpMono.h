//
// Created by Vojin on 3/13/2024.
//

#ifndef PERFECTHASHTEST_EXPMONO_H
#define PERFECTHASHTEST_EXPMONO_H
#include "typeDeclarations.h"
#include <string>

class ExpMono {
public:
    virtual ~ExpMono() = 0;
protected:
    constexpr static int lengthOfOperatorTableMono = 5;
    constexpr static char operatorArray = 'A';
};


#endif //PERFECTHASHTEST_EXPMONO_H
