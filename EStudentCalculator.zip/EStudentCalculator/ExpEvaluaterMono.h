//
// Created by Vojin on 3/12/2024.
//

#ifndef PERFECTHASHTEST_EXPEVALUATERMONO_H
#define PERFECTHASHTEST_EXPEVALUATERMONO_H
#include "ExpEvaluater.h"
#include "ExpMono.h"

class ExpEvaluaterMono : public ExpEvaluater, public ExpMono {
public:
    ExpEvaluaterMono(double* values, int len);
    double evaluateExpr(std::string &expr) override;
    ~ExpEvaluaterMono() override = default;

private:
    double* valuesArr;
    int valuesLen;

    const static funcP2 functionTableMono[lengthOfOperatorTableMono];

    static double maxArr(double* arr, int len);
    static double first(double* arr, int len);
    static double last(double* arr, int len);
    static double count(double* arr, int len);
    static double sum(double* arr, int len);
};


#endif //PERFECTHASHTEST_EXPEVALUATERMONO_H
