//
// Created by Vojin on 3/13/2024.
//

#ifndef PERFECTHASHTEST_EXPGENERATOR_H
#define PERFECTHASHTEST_EXPGENERATOR_H
#include "Exp.h"

class ExpGenerator : public Exp {
public:
    virtual std::string generateExpr(std::string& expr) = 0;
    ~ExpGenerator() override = 0;

protected:
    struct priority {
        int ipr;
        int spr;
        bool openBracket;
        bool openComa;
        bool operandBefore;
    };

    // Check Sequence
    bool didHappenDot; // nema vise od jedne tacke
    bool curr; // da li je trenutni levi operand
    int numOpenBracket; // broj otvorenih zagrada
    std::stack<bool> comaStack; // pravilne zapete

    // Generate Sequence
    uint64 code;
    std::string retData;
    std::string holder;
    int entry, entryPrio, prioTop, input;
    bool isNumber;
    std::stack<int> operatorInput;

    // Constants
    constexpr static int prioLength = 5;
    constexpr static int openBrackerEntry = 1;

    // Tables
    const static uint64 operatorTable[lengthOfOperatorTable];
    const static int operatorTablePrioEntry[lengthOfOperatorTable];
    const static priority prioTable[prioLength];

    // Functions
    static uint64 appendOperatorId(char, uint64);
    static int getOperatorTableIndex(uint64);
    static int getOperatorTableIndexReal(uint64, int, int, const uint64*);
    void initValues();
    bool updateHolderAndCheckNumber(char c);
    void restartHolderAndCode();
    bool checkCurrAndResetNumber();
    void checkConditionsOnPush();
    void comaCheck();
    void afterLoopAdjustments();

private:
    constexpr static int divideConst = 33;
    constexpr static int offset = 39;
};


#endif //PERFECTHASHTEST_EXPGENERATOR_H
