//
// Created by Vojin on 3/13/2024.
//

#include "ExpGeneratorMono.h"

const uint64 ExpGeneratorMono::operatorTableMono[lengthOfOperatorTableMono] = {
        33867877185,
        2640086481601,
        30748080961,
        11725185,
        627755841
};

const int ExpGeneratorMono::operatorTableMonoPrioEntry[lengthOfOperatorTableMono] = {
        2,
        2,
        2,
        2,
        2
};

ExpGeneratorMono::ExpGeneratorMono(std::string &sign) : sign(sign) {}

std::string ExpGeneratorMono::generateExpr(std::string & expr) {
    initValues();
    for (int i = 0; i < expr.length(); i++) {
        if(updateHolderAndCheckNumber(expr[i])) {
            if (monoReadingStatus == READING) throw -1;
            continue;
        }
        if(holder == sign || isNumber) {
            if (isNumber) {
                holder.pop_back();
                retData += holder + operand;
            }
            else {
                if (monoReadingStatus == READING) monoReadingStatus = READ;
            }
            restartHolderAndCode();
            if(checkCurrAndResetNumber()) continue;
        }
        code = appendOperatorId(expr[i], code);
        if (!code) throw -1;
        entry = getOperatorTableIndex(code);
        if (entry < 0) {
            entry = getOperatorMonoTableIndex(code);
            if (entry < 0) continue;
            entryPrio = operatorTableMonoPrioEntry[entry];
            isMono = true;
        }
        else {
            entryPrio = operatorTablePrioEntry[entry];
            isMono = false;
        }
        if (monoReadingStatus == READING) throw -1;
        else if (monoReadingStatus == READ && expr[i] != ')') throw -1;
        restartHolderAndCode();
        if (curr != prioTable[entryPrio].operandBefore) throw -1;
        while (!operatorInput.empty()) {
            if (operatorIsMono.top()) prioTop = prioTable[operatorTableMonoPrioEntry[operatorInput.top()]].spr;
            else prioTop = prioTable[operatorTablePrioEntry[operatorInput.top()]].spr;
            if (prioTable[entryPrio].ipr <= prioTop) {
                curr = true;
                popItems(input, isMono);
                retData += std::to_string(input) + (isMono ? operatorArray : operatorNumber);
            }
            else break;
        }
        if (expr[i] != ')' && expr[i] != ',') {
            if (isMono) monoReadingStatus = READING;
            checkConditionsOnPush();
            operatorInput.push(entry);
            operatorIsMono.push(isMono);
        }
        else {
            if (operatorInput.empty()) throw -1;
            if (expr[i] == ',') comaCheck();
            else {
                monoReadingStatus = NOT_READING;
                popItems(input, isMono);
                if (isMono && !prioTable[operatorTableMonoPrioEntry[input]].openBracket) throw -1;
                else if (!isMono && !prioTable[operatorTablePrioEntry[input]].openBracket) throw -1;
                if (--numOpenBracket < 0) throw -1;
                if (!isMono && prioTable[operatorTablePrioEntry[input]].openComa) {
                    if (!comaStack.top()) throw -1;
                    comaStack.pop();
                }
                if (!isMono && input == openBrackerEntry) continue;
                retData += std::to_string(input) + (isMono ? operatorArray : operatorNumber);
            }
        }
    }
    afterLoopAdjustments();
    while (!operatorInput.empty()) {
        popItems(input, isMono);
        retData += std::to_string(input) + (isMono ? operatorArray : operatorNumber);
    }
    return retData;
}

void ExpGeneratorMono::popItems(int& entry, bool& isMono) {
    entry = operatorInput.top();
    isMono = operatorIsMono.top();
    operatorInput.pop();
    operatorIsMono.pop();
}

int ExpGeneratorMono::getOperatorMonoTableIndex(uint64 index) {
    return getOperatorTableIndexReal(index, divideConst, lengthOfOperatorTableMono, operatorTableMono);
}

void ExpGeneratorMono::initValues() {
    ExpGenerator::initValues();
    monoReadingStatus = NOT_READING;
}
