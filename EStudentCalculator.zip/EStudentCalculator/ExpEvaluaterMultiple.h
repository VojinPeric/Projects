//
// Created by Vojin on 3/12/2024.
//

#ifndef PERFECTHASHTEST_EXPEVALUATERMULTIPLE_H
#define PERFECTHASHTEST_EXPEVALUATERMULTIPLE_H
#include "unordered_map"
#include "ExpEvaluater.h"

class ExpEvaluaterMultiple : public ExpEvaluater {
public:
    ExpEvaluaterMultiple(std::string* sign, double* values, int len);
    double evaluateExpr(std::string &expr) override;
    ~ExpEvaluaterMultiple() override = default;

private:
    std::unordered_map<std::string, double> symbolTable;
};


#endif //PERFECTHASHTEST_EXPEVALUATERMULTIPLE_H
