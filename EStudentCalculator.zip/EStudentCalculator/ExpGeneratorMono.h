//
// Created by Vojin on 3/13/2024.
//

#ifndef PERFECTHASHTEST_EXPGENERATORMONO_H
#define PERFECTHASHTEST_EXPGENERATORMONO_H
#include "ExpMono.h"
#include "ExpGenerator.h"

class ExpGeneratorMono : public ExpGenerator, public ExpMono {
public:
    ExpGeneratorMono(std::string &sign);
    std::string generateExpr(std::string &expr) override;
    ~ExpGeneratorMono() override = default;
private:
    enum monoStatus {NOT_READING, READING, READ};

    std::stack<bool> operatorIsMono;
    std::string sign;
    bool isMono;
    monoStatus monoReadingStatus;

    constexpr static int divideConst = 54;

    const static int operatorTableMonoPrioEntry[lengthOfOperatorTableMono];
    const static uint64 operatorTableMono[lengthOfOperatorTableMono];

    static int getOperatorMonoTableIndex(uint64 index);
    void popItems(int& entry, bool& isMono);
    void initValues();
};


#endif //PERFECTHASHTEST_EXPGENERATORMONO_H
