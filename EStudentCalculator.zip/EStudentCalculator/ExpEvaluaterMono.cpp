//
// Created by Vojin on 3/12/2024.
//

#include "ExpEvaluaterMono.h"
// pogledaj smanjenje tabele
// podaci se pushuju na stek
const funcP2 ExpEvaluaterMono::functionTableMono[lengthOfOperatorTableMono] = {
    &first,
    &maxArr,
    &count,
    &sum,
    &last
};

ExpEvaluaterMono::ExpEvaluaterMono(double* values, int len) : valuesLen(len), valuesArr(values) {}

double ExpEvaluaterMono::evaluateExpr(std::string &expr) {
    for (int i = 0; i < expr.length(); i++) {
        if (expr[i] == operand) {
            value = std::strtod(holder.c_str(), nullptr);
            operands.push(value);
            holder = "";
            continue;
        }
        if (expr[i] == operatorNumber || expr[i] == operatorArray) {
            key = atoi(holder.c_str());
            if (expr[i] == operatorNumber) functionTable[key](operands);
            else operands.push(functionTableMono[key](valuesArr, valuesLen));
            holder = "";
            continue;
        }
        holder += expr[i];
    }
    value = operands.top();
    operands.pop();
    return value;
}

double ExpEvaluaterMono::maxArr(double *arr, int len) {
    double max = 0;
    for (int i = 0; i < len; i++) if (arr[i] > max) max = arr[i];
    return max;
}

double ExpEvaluaterMono::first(double *arr, int len) {
    if (!len) return -1;
    return arr[0];
}

double ExpEvaluaterMono::last(double *arr, int len) {
    if (!len) return -1;
    return arr[len - 1];
}

double ExpEvaluaterMono::count(double *arr, int len) {
    return len;
}

double ExpEvaluaterMono::sum(double *arr, int len) {
    double sum = 0;
    for(int i = 0; i < len; i++) sum += arr[i];
    return sum;
}
