//
// Created by Vojin on 3/12/2024.
//

#include "ExpEvaluater.h"

const funcP ExpEvaluater::functionTable[lengthOfOperatorTable] = {
    &max,
    nullptr,
    nullptr,
    &times,
    &plus,
    nullptr,
    &minus,
    &floor,
    &divide,
    &ceil
};

void ExpEvaluater::plus(std::stack<double> & s) {
    double ret = s.top();
    s.pop();
    s.top() += ret;
}

void ExpEvaluater::minus(std::stack<double> & s) {
    double ret = s.top();
    s.pop();
    s.top() -= ret;
}

void ExpEvaluater::times(std::stack<double> & s) {
    double ret = s.top();
    s.pop();
    s.top() *= ret;
}

void ExpEvaluater::divide(std::stack<double> & s) {
    double ret = s.top();
    s.pop();
    s.top() /= ret;
}

void ExpEvaluater::max(std::stack<double> & s) {
    double ret = s.top();
    s.pop();
    s.top() = (ret > s.top() ? ret : s.top());
}

void ExpEvaluater::ceil(std::stack<double> & s) {
    s.top() = (s.top() == (double)((int)s.top()) ? s.top() : (int)s.top() + 1);
}

void ExpEvaluater::floor(std::stack<double> & s) {
    s.top() = (int)s.top();
}

ExpEvaluater::~ExpEvaluater() = default;
