//
// Created by Vojin on 3/13/2024.
//

#ifndef PERFECTHASHTEST_EXPGENERATORMULTIPLE_H
#define PERFECTHASHTEST_EXPGENERATORMULTIPLE_H
#include "ExpGenerator.h"
#include <set>

class ExpGeneratorMultiple : public ExpGenerator {
public:
    ExpGeneratorMultiple(std::string *sign, int len);
    std::string generateExpr(std::string &expr) override;
    ~ExpGeneratorMultiple() override = default;

private:
    std::set<std::string> signs;

    void popItems(int& entry);
};


#endif //PERFECTHASHTEST_EXPGENERATORMULTIPLE_H
