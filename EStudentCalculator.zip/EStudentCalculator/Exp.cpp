//
// Created by Vojin on 3/12/2024.
//

#include "Exp.h"

Exp::~Exp() = default;
