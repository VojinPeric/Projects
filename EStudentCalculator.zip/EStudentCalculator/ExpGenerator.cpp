//
// Created by Vojin on 3/13/2024.
//

#include "ExpGenerator.h"

const uint64 ExpGenerator::operatorTable[lengthOfOperatorTable] = {
        10071105,
        1,
        2,
        3,
        4,
        5,
        6,
        33917405889,
        8,
        477768001
};

const int ExpGenerator::operatorTablePrioEntry[lengthOfOperatorTable] = {
    4,
    2,
    3,
    1,
    0,
    3,
    0,
    2,
    1,
    2
};

const ExpGenerator::priority ExpGenerator::prioTable[prioLength] = {
        {2, 2, false, false, true},
        {3, 3, false, false, true},
        {6, 0, true, false, false},
        {1, 0, false, false, true},
        {6, 0, true, true, false}
};

uint64 ExpGenerator::appendOperatorId(char c, uint64 number) {
    if ((number & (~((uint64)(-1) >> 6))) || (c < 40 || c > 90)) return 0;
    number <<= 6;
    return number + c - offset;
}

int ExpGenerator::getOperatorTableIndex(uint64 n) {
    return getOperatorTableIndexReal(n, divideConst, lengthOfOperatorTable, operatorTable);
}

int ExpGenerator::getOperatorTableIndexReal(uint64 n, int devideConstA, int lengthOfOperatorTableA, const uint64* operatorTableA) {
    int index = (n + n / devideConstA) % lengthOfOperatorTableA;
    if (operatorTableA[index] == n) return index;
    return -1;
}

void ExpGenerator::initValues() {
    // Check Sequence
    didHappenDot = false;
    curr = false;
    numOpenBracket = 0;
    while(!comaStack.empty()) comaStack.pop();

    // Generate Sequence
    code = 0;
    retData = "";
    holder = "";
    isNumber = false;
    while(!operatorInput.empty()) operatorInput.pop();
}

bool ExpGenerator::updateHolderAndCheckNumber(char c) { // true - continue, false - proceed
    if (c == ' ') return true;
    holder += c;
    if (((c - '0' >= 0 && c - '0' < 10) || (c == '.')) && !code) {
        if (didHappenDot && c == '.') throw -1;
        else if (c == '.') didHappenDot = true;
        isNumber = true;
        return true;
    }
    return false;
}

void ExpGenerator::restartHolderAndCode() {
    holder = "";
    code = 0;
}

bool ExpGenerator::checkCurrAndResetNumber() { // true - continue, false - proceed
    if (curr) throw -1;
    curr = true;
    if (!isNumber) return true;
    didHappenDot = false;
    isNumber = false;
    return false;
}

void ExpGenerator::checkConditionsOnPush() {
    if (prioTable[entryPrio].operandBefore) curr = false;
    if (prioTable[entryPrio].openBracket) numOpenBracket++;
    if (prioTable[entryPrio].openComa) comaStack.push(false);
}

void ExpGenerator::comaCheck() {
    if (!prioTable[operatorTablePrioEntry[operatorInput.top()]].openComa) throw -1;
    if (comaStack.top()) throw -1;
    comaStack.top() = true;
    curr = false;
}

void ExpGenerator::afterLoopAdjustments() {
    if (numOpenBracket) throw -1;
    if (holder != "" && ((holder[0] - '0' >= 0 && holder[0] - '0' < 10) || (holder[0] == '.'))) {
        if (curr) throw -1;
        curr = true;
        retData += holder + operand;
    }
    else if (holder != "") throw -1;
    if (!curr && !operatorInput.empty()) throw -1;
}

ExpGenerator::~ExpGenerator() = default;