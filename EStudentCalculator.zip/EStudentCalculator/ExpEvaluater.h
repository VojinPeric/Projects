//
// Created by Vojin on 3/12/2024.
//

#ifndef PERFECTHASHTEST_EXPEVALUATER_H
#define PERFECTHASHTEST_EXPEVALUATER_H
#include "Exp.h"

class ExpEvaluater : public Exp{
public:
    virtual double evaluateExpr(std::string& expr) = 0;
    ~ExpEvaluater() override = 0;

protected:
    std::stack<double> operands;
    std::string holder;
    double value;
    int key;

    const static funcP functionTable[lengthOfOperatorTable];

    static void plus(std::stack<double>&);
    static void minus(std::stack<double>&);
    static void times(std::stack<double>&);
    static void divide(std::stack<double>&);
    static void max(std::stack<double>&);
    static void ceil(std::stack<double>&);
    static void floor(std::stack<double>&);
};

#endif //PERFECTHASHTEST_EXPEVALUATER_H
