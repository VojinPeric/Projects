package V3LABP;

import java.awt.Graphics;

public abstract class Akter {
	protected Teren teren;
	private Pozicija poz;

	public Akter(Teren teren, Pozicija poz) {
		super();
		this.teren = teren;
		this.poz = poz;
	}

	public Pozicija getPoz() {
		return poz;
	}

	public void setPoz(Pozicija poz) {
		this.poz = poz;
	}

	public abstract void paint(Graphics g);
}
