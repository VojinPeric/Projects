package V3LABP;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Igra extends Frame {
	private Teren teren;
	private Panel sideBar;
	
	private void populateWindow() {
		teren = new Teren(6, 12);
		add(teren, BorderLayout.CENTER);
		
		CheckboxGroup g = new CheckboxGroup();
		Checkbox zid = new Checkbox("Zid");
		zid.setCheckboxGroup(g);
		Checkbox prolaz = new Checkbox("Prolaz");
		prolaz.setCheckboxGroup(g);
		Checkbox akter = new Checkbox("Akter");
		akter.setCheckboxGroup(g);
		Button postavi = new Button("Postavi");
		postavi.addActionListener((e)->{
			Checkbox c = g.getSelectedCheckbox();
			if (c == null) return;
			String s = c.getLabel();
			if (s == "Zid") {
				teren.setPolje(new Zid(teren, null));
			}
			else if (s == "Prolaz") {
				teren.setPolje(new Prolaz(teren, null));
			}
			else {
				try {
					teren.setAkter();
				} catch (PoljeJeZid e1) {
					System.out.println(e1.getMessage());
				}
			}
		});
		Button nasumicno = new Button("Nasumicno");
		nasumicno.addActionListener((e)-> {
			teren.generisiRandomPolja();
		});
		
		sideBar = new Panel(new GridLayout(3, 0));
		
		Panel checkBoxPanel = new Panel();
		checkBoxPanel.add(zid);
		checkBoxPanel.add(prolaz);
		checkBoxPanel.add(akter);
		sideBar.add(checkBoxPanel);
		sideBar.add(postavi);
		sideBar.add(nasumicno);
		add(sideBar, BorderLayout.EAST);
	}
	
	public Igra () {
		setResizable(false);
		
		populateWindow();
		
		pack();
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				dispose();
			}
		});
		
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new Igra();
	}
}
