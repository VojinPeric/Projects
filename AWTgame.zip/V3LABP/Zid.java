package V3LABP;

import java.awt.Color;

public class Zid extends Polje {

	public Zid(Teren teren, Pozicija poz) {
		super(Color.DARK_GRAY, teren, poz);
	}

	@Override
	public boolean mozeDaStane() {
		return false;
	}

}
