package V3LABP;

import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.event.MouseAdapter;
import java.util.ArrayList;

public class Teren extends Panel {
	private int vrste;
	private int kolone;
	private Polje[][] polja;
	private Polje oznacen = null;
	private ArrayList<Akter> listaAktera = new ArrayList<Akter>();
	
	private final int SUQARE_SIZE = 50;

	public Teren(int vrste, int kolone) {
		super();
		this.vrste = vrste;
		this.kolone = kolone;
		
		setSize(kolone * SUQARE_SIZE, vrste * SUQARE_SIZE);
		setPreferredSize(getSize());
		
		setLayout(new GridLayout(vrste, kolone, 0, 0));
		
		polja = new Polje[vrste][kolone];
		
		for (int i = 0; i < vrste; i++) {
			for (int j = 0; j < kolone; j++) {
				polja[i][j] = new Prolaz(this, new Pozicija(i, j));
				add(polja[i][j]);
			}
		}
	}

	public int getPoljeVisina() {
		return SUQARE_SIZE;
	}

	public int getPoljeDuzina() {
		return SUQARE_SIZE;
	}
	
	public void setAkter() throws PoljeJeZid {
		if (oznacen == null) return;
		if (oznacen instanceof Zid) throw new PoljeJeZid();
		listaAktera.add(new GlavniAkter(this, new Pozicija(oznacen.getPoz().getVrsta(), oznacen.getPoz().getKolona())));
		oznacen.repaint();
	}

	public Akter getAkter(Pozicija poz) {
		for (Akter akter : listaAktera) {
			if (akter.getPoz().equals(poz)) {
				return akter;
			}
		}
		return null;
	}

	public void poljeKliknuto(Polje polje) {
		if (oznacen != null) oznacen.setOznacen(false);
		polje.setOznacen(true);
		if (oznacen != null) oznacen.repaint();
		polje.repaint();
		oznacen = polje;
	}
	
	public void generisiRandomPolja () {
		for (int i = 0; i < vrste; i++) {
			for (int j = 0; j < kolone; j++) {
				double rand = Math.random();
				if (rand < 0.3) {
					polja[i][j] = new Zid(this, new Pozicija(i, j));
				}
				else {
					polja[i][j] = new Prolaz(this, new Pozicija(i, j));
				}
				remove(i * kolone + j);
				add(polja[i][j], i * kolone + j);
			}
		}
		oznacen = null;
		listaAktera.clear();
		revalidate();
	}
	
	public void setPolje(Polje p) {
		if (oznacen == null) return;
		if (p instanceof Zid && oznacen.jelAkterNaPolju()) {
			System.out.println("kita");
			return;
		}
		
		p.setPoz(oznacen.getPoz());
		
		remove(oznacen.getPoz().getVrsta() * kolone + oznacen.getPoz().getKolona());
		add(p, oznacen.getPoz().getVrsta() * kolone + oznacen.getPoz().getKolona());
		
		revalidate();
		
		polja[oznacen.getPoz().getVrsta()][oznacen.getPoz().getKolona()] = p;
		
		oznacen = p;
		p.setOznacen(true);
		p.repaint();
	}
	
	public Polje getPoljeSaPozicijom (Pozicija p) {
		return polja[p.getVrsta()][p.getKolona()];
	}
}
