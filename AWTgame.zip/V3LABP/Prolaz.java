package V3LABP;

import java.awt.Color;

public class Prolaz extends Polje {
	
	public Prolaz(Teren teren, Pozicija poz) {
		super(Color.LIGHT_GRAY, teren, poz);
	}

	@Override
	public boolean mozeDaStane() {
		return true;
	}

}
