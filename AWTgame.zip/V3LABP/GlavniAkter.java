package V3LABP;

import java.awt.Color;
import java.awt.Graphics;

public class GlavniAkter extends Akter {

	public GlavniAkter(Teren teren, Pozicija poz) {
		super(teren, poz);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void paint(Graphics g) {
		Color c = g.getColor();
		g.setColor(Color.YELLOW);
		g.fillOval(1, 1, teren.getPoljeDuzina() - 2, teren.getPoljeVisina() - 2);
		g.setColor(Color.BLACK);
		g.drawOval(1, 1, teren.getPoljeDuzina() - 2, teren.getPoljeVisina() - 2);
		g.setColor(c);
	}

}
