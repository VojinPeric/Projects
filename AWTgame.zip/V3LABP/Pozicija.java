package V3LABP;

public class Pozicija {
	public enum Smer { GORE, DOLE, LEVO, DESNO }
	
	private int vrsta;
	private int kolona;

	public Pozicija(int vrsta, int kolona) {
		super();
		this.vrsta = vrsta;
		this.kolona = kolona;
	}

	public int getVrsta() {
		return vrsta;
	}

	public int getKolona() {
		return kolona;
	}

	public Pozicija getRelativnaPozicija(Smer s) {
		if (s == Smer.GORE) return new Pozicija(vrsta + 1, kolona);
		if (s == Smer.DOLE) return new Pozicija(vrsta - 1, kolona);
		if (s == Smer.LEVO) return new Pozicija(vrsta, kolona - 1);
		return new Pozicija(vrsta, kolona + 1);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Pozicija)) return false;
		Pozicija ob = (Pozicija) obj;
		return vrsta == ob.vrsta && kolona == ob.kolona;
	}
}
