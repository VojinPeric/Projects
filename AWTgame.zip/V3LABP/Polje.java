package V3LABP;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public abstract class Polje extends Canvas {
	private Color c;
	private Teren teren;
	private Pozicija poz;
	private boolean oznacen = false;

	public Polje(Color c, Teren teren, Pozicija poz) {
		super();
		this.c = c;
		this.teren = teren;
		this.poz = poz;
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.println("eee");
				teren.poljeKliknuto(Polje.this);
			}
		});
	}

	public Pozicija getPoz() {
		return poz;
	}
	
	public void setPoz(Pozicija p) { poz = p; }
 
	public void setOznacen(boolean oznacen) {
		this.oznacen = oznacen;
	}

	public abstract boolean mozeDaStane();
	
	public boolean jelAkterNaPolju() {
		return getGlavniAkterNaPoziciji() != null;
	}
	
	public Akter getGlavniAkterNaPoziciji() {
		Akter a = teren.getAkter(poz);
		if (a == null) return null;
		//if (!(a instanceof GlavniAkter)) return null;
		return a;
	}
 	
	public boolean getOznacen() { return oznacen; }
	
	@Override
	public void paint(Graphics g) {
		Color prev = g.getColor();
		g.setColor(c);
		g.fillRect(0, 0, teren.getPoljeDuzina(), teren.getPoljeVisina());
		
		if (jelAkterNaPolju()) {
			getGlavniAkterNaPoziciji().paint(g);
		}
		
		if (oznacen) g.setColor(Color.RED);
		else g.setColor(Color.BLACK);
		
		g.drawRect(1, 1, teren.getPoljeDuzina() - 2, teren.getPoljeVisina() - 2);
		
		g.setColor(prev);
	}
	
	
	
 }
