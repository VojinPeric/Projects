package V3LABP;

public class PoljeJeZid extends Exception {

	public PoljeJeZid() {
		super("Polje je zid!");
	}

}
