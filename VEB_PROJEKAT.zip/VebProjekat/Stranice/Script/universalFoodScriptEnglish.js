let messageVoted = "You have already voted for this dish!";
let messageSelected = "You have to select the size first!";