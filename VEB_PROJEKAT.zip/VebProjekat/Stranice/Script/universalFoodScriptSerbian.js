let messageVoted = "Već je glasano za ovog korisnika!";
let messageSelected = "Mora da se selektuje veličina!";