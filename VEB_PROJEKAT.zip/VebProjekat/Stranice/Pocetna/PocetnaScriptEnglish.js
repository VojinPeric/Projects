$(document).ready(function(){
    $("#btn1").click(function(){
        window.open('../../menuEnglish.pdf', '_blank');
    });
});
