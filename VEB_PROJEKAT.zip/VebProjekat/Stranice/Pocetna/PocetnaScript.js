$(document).ready(function(){
    $("#btn1").click(function(){
        window.open('../../menuSrpski.pdf', '_blank');
    });
});
