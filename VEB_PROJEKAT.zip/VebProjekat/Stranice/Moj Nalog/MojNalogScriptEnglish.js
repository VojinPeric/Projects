let dishNames = {
    "Predjelo1": "Kung Pao Spicy Shrimp",
    "Predjelo2": "Chicken in Spicy Honey Sauce",
    "Predjelo3": "Meat Rolls with Unagi Sauce",
    "GlavnoJelo1": "Sour Sweet Chicken",
    "GlavnoJelo2": "Traditional Noodles with Vegetables",
    "GlavnoJelo3": "Chinese Salad",
    "Dezert1": "Fruit Dumplings",
    "Dezert2": "Sweet and Spicy Chicken",
    "Dezert3": "Moon Cake"
}

let wordsTranslator = {
    "Order" : "Order",
    "Price" : "price",
    "Bigger" : "Enlarge",
    "Smaller" : "Reduce",
    "Delete" : "Remove"
}

let dishSize = {
    "Velika" : "Big",
    "Mala" : "Small"
}