let dishNames = {
    "Predjelo1": "Kung Pao pikant gambori",
    "Predjelo2": "Piletina u pikant umaku od meda",
    "Predjelo3": "Mesne rolnice sa Unagi umakom",
    "GlavnoJelo1": "Kiselo ljudta piletina",
    "GlavnoJelo2": "Tradicionalne nudle sa povrćem",
    "GlavnoJelo3": "Kineska salata",
    "Dezert1": "Knedle sa voćem",
    "Dezert2": "Slatko ljuta piletina",
    "Dezert3": "Mesečev kolač"
}

let wordsTranslator = {
    "Order" : "Narudžbina",
    "Price" : "cena",
    "Bigger" : "Uvećaj",
    "Smaller" : "Smanji",
    "Delete" : "Ukloni"
}

let dishSize = {
    "Velika" : "Velika",
    "Mala" : "Mala"
}