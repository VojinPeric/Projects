let messageEmail = "Email already exists!";
let messageUser = "Username already exists!";