let messageEmail = "Email već postoji!";
let messageUser = "Username već postoji!";